'use strict';
/* AIRPORT ESCAPE - authoritative game server (Node.js + Socket.IO) */
const http = require('http');
const fs = require('fs');
const path = require('path');
const { Server } = require('socket.io');
const S = require('./shared/common.js');

const PORT = process.env.PORT || 3000;
const TICK_MS = 66;   // ~15 snapshots per second

/* ---------------- tiny static file server ---------------- */
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'application/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json', '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon' };
const server = http.createServer(function (req, res) {
  let url = decodeURIComponent((req.url || '/').split('?')[0]);
  if (url === '/') url = '/index.html';
  let file;
  if (url.indexOf('/shared/') === 0) file = path.join(__dirname, url);
  else file = path.join(__dirname, 'public', url);
  const base = url.indexOf('/shared/') === 0 ? path.join(__dirname, 'shared') : path.join(__dirname, 'public');
  if (file.indexOf(base) !== 0) { res.writeHead(403); return res.end('Forbidden'); }
  fs.readFile(file, function (err, data) {
    if (err) { res.writeHead(404); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    res.end(data);
  });
});

const io = new Server(server, { cors: { origin: '*' }, transports: ['websocket', 'polling'] });

/* ---------------- rooms ---------------- */
const rooms = new Map();

function makeRoom(code) {
  return { code: code, players: new Map(), phase: 'lobby', hostId: null, seed: (Math.random() * 1e9) | 0, epoch: Date.now(),
    playStart: 0, freezeUntil: 0, roundEnd: 0, roundId: 0 };
}
function cleanName(n) { return String(n || '').replace(/[^\w \-]/g, '').trim().slice(0, 14) || 'Player'; }
function cleanCode(c) { return String(c || 'MAIN').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8) || 'MAIN'; }
function teamCount(room, team) { let n = 0; room.players.forEach(function (p) { if (p.team === team) n++; }); return n; }

function lobbyPayload(room) {
  const list = [];
  room.players.forEach(function (p) { list.push({ id: p.id, name: p.name, team: p.team }); });
  return { code: room.code, phase: room.phase, hostId: room.hostId, seed: room.seed, epoch: room.epoch, now: Date.now(), players: list };
}
function broadcastLobby(room) { io.to(room.code).emit('lobby', lobbyPayload(room)); }

function startRound(room) {
  const pol = [], smu = [];
  room.players.forEach(function (p) { (p.team === 'police' ? pol : smu).push(p); });
  const spawns = {};
  pol.forEach(function (p, i) { setSpawn(p, S.spawn('police', i, pol.length), spawns); });
  smu.forEach(function (p, i) { setSpawn(p, S.spawn('smuggler', i, smu.length), spawns); });
  const now = Date.now();
  room.roundId++;
  room.seed = (Math.random() * 1e9) | 0;
  room.phase = 'countdown';
  room.playStart = now + S.COUNTDOWN_MS;
  room.freezeUntil = room.playStart + S.POLICE_FREEZE_MS;
  room.roundEnd = room.playStart + S.ROUND_MS;
  const roster = [];
  room.players.forEach(function (p) { roster.push({ id: p.id, name: p.name, team: p.team }); });
  io.to(room.code).emit('round', { code: room.code, seed: room.seed, epoch: room.epoch, now: now, playStart: room.playStart,
    freezeUntil: room.freezeUntil, roundEnd: room.roundEnd, spawns: spawns, players: roster, hostId: room.hostId });
}
function setSpawn(p, sp, spawns) {
  p.x = sp[0]; p.z = sp[1]; p.ry = sp[2]; p.anim = 0; p.alive = true; p.caps = 0; p.escaped = false;
  p.lastT = Date.now(); p.lastCatch = 0; p.strikes = 0;
  spawns[p.id] = sp;
}

function endRound(room, winner, reason) {
  if (room.phase !== 'countdown' && room.phase !== 'playing') return;
  room.phase = 'ended';
  const results = [];
  room.players.forEach(function (p) { results.push({ id: p.id, name: p.name, team: p.team, alive: p.alive, caps: p.caps, escaped: p.escaped }); });
  io.to(room.code).emit('end', { winner: winner, reason: reason, results: results });
}

function checkWin(room) {
  if (room.phase !== 'playing' && room.phase !== 'countdown') return;
  let pol = 0, smu = 0, alive = 0;
  room.players.forEach(function (p) {
    if (p.team === 'police') pol++;
    else { smu++; if (p.alive) alive++; }
  });
  if (pol === 0) return endRound(room, 'smuggler', 'All police left the match');
  if (smu === 0) return endRound(room, 'police', 'All smugglers left the match');
  if (alive === 0) return endRound(room, 'police', 'All smugglers were captured');
}

function tickRoom(room, now) {
  if (room.phase === 'lobby') return;
  if (room.phase === 'countdown' && now >= room.playStart) room.phase = 'playing';
  if (room.phase === 'playing') {
    let escaped = null;
    room.players.forEach(function (p) {
      if (!escaped && p.team === 'smuggler' && p.alive && S.inRect(p.x, p.z, S.EXIT)) escaped = p;
    });
    if (escaped) { escaped.escaped = true; return endRound(room, 'smuggler', escaped.name + ' reached the exit'); }
    if (now >= room.roundEnd) return endRound(room, 'police', 'Time ran out - the smugglers were held up');
  }
  const arr = [];
  room.players.forEach(function (p) {
    arr.push([p.id, +p.x.toFixed(2), +p.z.toFixed(2), +p.ry.toFixed(2), p.anim, p.alive ? 1 : 0]);
  });
  io.to(room.code).emit('snap', { t: now, p: arr });
}
setInterval(function () {
  const now = Date.now();
  rooms.forEach(function (room) { tickRoom(room, now); });
}, TICK_MS);

/* ---------------- sockets ---------------- */
io.on('connection', function (socket) {
  let room = null, me = null;

  socket.on('ping', function (ack) { if (typeof ack === 'function') ack(Date.now()); });

  socket.on('join', function (data, ack) {
    if (typeof ack !== 'function') ack = function () {};
    if (me) return ack({ ok: false, err: 'Already joined' });
    data = data || {};
    const code = cleanCode(data.room);
    let r = rooms.get(code);
    if (!r) { r = makeRoom(code); rooms.set(code, r); }
    if (r.phase === 'countdown' || r.phase === 'playing') return ack({ ok: false, err: 'A match is in progress in room ' + code + '. Try another room code or wait.' });
    if (r.players.size >= S.MAX_PLAYERS) return ack({ ok: false, err: 'Room ' + code + ' is full' });
    room = r;
    me = { id: socket.id, name: cleanName(data.name), team: teamCount(r, 'police') < teamCount(r, 'smuggler') ? 'police' : 'smuggler',
      x: 0, z: 0, ry: 0, anim: 0, alive: true, caps: 0, escaped: false, lastT: 0, lastCatch: 0, strikes: 0 };
    r.players.set(me.id, me);
    if (!r.hostId) r.hostId = me.id;
    socket.join(r.code);
    ack({ ok: true, id: me.id, lobby: lobbyPayload(r) });
    broadcastLobby(r);
  });

  socket.on('team', function (team) {
    if (!me || (room.phase !== 'lobby' && room.phase !== 'ended')) return;
    if (team !== 'police' && team !== 'smuggler') return;
    if (teamCount(room, team) >= S.MAX_PER_TEAM && me.team !== team) return socket.emit('toast', 'That team is full');
    me.team = team;
    broadcastLobby(room);
  });

  socket.on('start', function () {
    if (!me || (room.phase !== 'lobby' && room.phase !== 'ended')) return;
    if (room.hostId !== me.id) return socket.emit('toast', 'Only the host can start the match');
    if (!teamCount(room, 'police') || !teamCount(room, 'smuggler')) return socket.emit('toast', 'Need at least 1 Police and 1 Smuggler');
    startRound(room);
  });

  socket.on('restart', function () {          // "Play Again" on the results screen
    if (!me || room.phase !== 'ended') return;
    if (teamCount(room, 'police') && teamCount(room, 'smuggler')) startRound(room);
    else { room.phase = 'lobby'; broadcastLobby(room); socket.emit('toast', 'Need at least 1 Police and 1 Smuggler'); }
  });

  socket.on('toLobby', function () {
    if (!me || room.phase !== 'ended') return;
    room.phase = 'lobby';
    broadcastLobby(room);
  });

  socket.on('st', function (a) {             // client movement state: [x, z, ry, anim]
    if (!me || room.phase !== 'playing' || !me.alive || !Array.isArray(a)) return;
    const now = Date.now();
    if (me.team === 'police' && now < room.freezeUntil) return;
    const x = +a[0], z = +a[1], ry = +a[2], an = a[3] | 0;
    if (!isFinite(x) || !isFinite(z) || !isFinite(ry)) return;
    const dt = Math.min(Math.max(now - me.lastT, 30), 600) / 1000;
    const maxD = S.RUN * S.POLICE_BONUS * 1.7 * dt + 1.2;
    if (Math.hypot(x - me.x, z - me.z) > maxD) {          // too fast: teleport the client back
      me.strikes++; me.lastT = now;
      return socket.emit('fix', [me.x, me.z]);
    }
    const B = S.BOUNDS;
    me.x = Math.min(Math.max(x, B.x1), B.x2); me.z = Math.min(Math.max(z, B.z1), B.z2);
    me.ry = ry; me.anim = an < 0 ? 0 : an > 2 ? 2 : an; me.lastT = now;
  });

  socket.on('catch', function () {
    if (!me || room.phase !== 'playing' || me.team !== 'police' || !me.alive) return;
    const now = Date.now();
    if (now < room.freezeUntil || now - me.lastCatch < 700) return;
    me.lastCatch = now;
    let best = null, bd = S.CATCH_RANGE_SERVER;
    room.players.forEach(function (p) {
      if (p.team !== 'smuggler' || !p.alive) return;
      const d = Math.hypot(p.x - me.x, p.z - me.z);
      if (d <= bd) { bd = d; best = p; }
    });
    if (!best) return socket.emit('miss');
    best.alive = false; best.anim = 0; me.caps++;
    let left = 0;
    room.players.forEach(function (p) { if (p.team === 'smuggler' && p.alive) left++; });
    io.to(room.code).emit('cap', { id: best.id, name: best.name, by: me.id, byName: me.name, left: left });
    checkWin(room);
  });

  socket.on('disconnect', function () {
    if (!me || !room) return;
    room.players.delete(me.id);
    if (room.players.size === 0) { rooms.delete(room.code); return; }
    if (room.hostId === me.id) room.hostId = room.players.keys().next().value;
    broadcastLobby(room);
    checkWin(room);
  });
});

server.listen(PORT, function () { console.log('AIRPORT ESCAPE server running on http://localhost:' + PORT); });
