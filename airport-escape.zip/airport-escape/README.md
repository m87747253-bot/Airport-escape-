# AIRPORT ESCAPE

Low-poly 3D multiplayer **Cops vs Smugglers** game set in a large international airport.
Node.js + Socket.IO server, Three.js client, built for mobile browsers.

## Run it

```bash
npm install
npm start            # http://localhost:3000   (PORT env var to change)
```

Open the URL on several devices/tabs (same Wi-Fi: `http://<your-computer-ip>:3000`), enter a name and the
**same room code**, pick a team in the lobby, and the host presses **START MATCH**.
To play over the internet, deploy the folder to any Node host (Render, Railway, Fly.io, a VPS...) - it serves the
game and the WebSocket on one port. Three.js is loaded from the cdnjs CDN, so clients need internet access.

A match needs at least **1 Police and 1 Smuggler** (use two browser tabs to test alone).

## How to play

| | |
|---|---|
| **Smugglers** | Start at the boarding gates. Run through security, the check-in hall, out the main doors, across the road and through the parking lot to the glowing green **EXIT ZONE**. First smuggler in wins for their team. |
| **Police** | Start in the check-in hall, released 5 s after the smugglers. Get within ~3 m of a smuggler and press **CATCH**. Captured smugglers are out for the round. |
| **Round ends** | Smuggler reaches exit (smugglers win) - all smugglers captured, or 3:00 timer runs out (police win). Results screen + **Restart** button. |

Controls - PC: `WASD` move, `Shift` run, drag mouse to look, `Space`/`E` catch, `Q` switch spectated player.
Phone: left thumb = floating stick (push to the edge to sprint), drag right side to look, `CATCH` button for police.
Running uses stamina (green bar); when empty you walk until it recovers.

## Architecture

```
server.js            Node http (static files) + Socket.IO: rooms, lobby/teams, authoritative capture,
                     exit-zone detection, speed/teleport validation, timer, restart
shared/common.js     Used by BOTH server and browser: constants, map colliders, spawns,
                     deterministic NPC generator (position = f(seed, time))
public/index.html    UI markup            public/css/style.css   UI styling
public/js/worldkit.js, world-interior.js, world-exterior.js
                     Builds the airport; all static geometry is merged into a few vertex-coloured meshes
public/js/chars.js   Every character (NPCs + players) is ONE InstancedMesh = 1 draw call;
                     procedural walk / run / sit / idle / cuffed animation, name labels, interpolation
public/js/net.js     Socket.IO client + server-clock sync      public/js/input.js  keyboard/mouse/touch
public/js/hud.js     Menu, lobby, HUD, results, mini-map       public/js/game.js   main loop, physics, camera
```

**Networking:** clients send their position/animation at ~15 Hz; the server validates speed, owns capture and
win logic, and broadcasts ~15 snapshots/s per room; remote players are interpolated ~110 ms behind.
**NPCs cost zero bandwidth:** the server only shares a seed + clock, and every client computes the same ~150-200
crowd members (walkers, seated passengers, check-in/gate staff, security guards) from `position = f(seed, time)`.
NPCs avoid the player and each other, and the player collides with them and with every wall, counter and car.

## Tuning

Gameplay numbers (speeds, stamina, round length, head start, catch range, team size) are at the top of
`shared/common.js`. Weak phones automatically get fewer NPCs and a lower render resolution (adaptive).
