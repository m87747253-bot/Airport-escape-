/* AIRPORT ESCAPE - keyboard + mouse + touch (floating joystick, drag-to-look) input. */
(function () {
  'use strict';
  const keys = {};
  const I = {
    ix: 0, iy: 0, run: false,           // move vector (x right, y forward) in -1..1
    yaw: 0, pitch: 0.38, dist: 5.6,
    active: false,                      // true while the 3D game is being controlled
    touch: ('ontouchstart' in window) || navigator.maxTouchPoints > 0,
    onCatch: null, onSpectate: null
  };
  let joy = null, cam = null, runBtn = false, stickEl, knobEl, lastX = 0, lastY = 0, mouseDown = false;
  const R = 56;

  function recompute() {
    if (joy) return;
    I.ix = (keys.KeyD || keys.ArrowRight ? 1 : 0) - (keys.KeyA || keys.ArrowLeft ? 1 : 0);
    I.iy = (keys.KeyW || keys.ArrowUp ? 1 : 0) - (keys.KeyS || keys.ArrowDown ? 1 : 0);
    I.run = !!(keys.ShiftLeft || keys.ShiftRight) || runBtn;
  }
  function look(dx, dy) {
    I.yaw -= dx * 0.0052; I.pitch = Math.min(1.2, Math.max(0.06, I.pitch + dy * 0.004));
  }

  I.init = function () {
    stickEl = document.getElementById('stick'); knobEl = document.getElementById('knob');
    window.addEventListener('keydown', function (e) {
      if (e.target && /INPUT|TEXTAREA/.test(e.target.tagName)) return;
      keys[e.code] = true; recompute();
      if (!I.active) return;
      if (e.code === 'Space' || e.code === 'KeyE' || e.code === 'KeyF') { e.preventDefault(); if (I.onCatch) I.onCatch(); }
      if (e.code === 'KeyQ' || e.code === 'Tab') { e.preventDefault(); if (I.onSpectate) I.onSpectate(); }
    });
    window.addEventListener('keyup', function (e) { keys[e.code] = false; recompute(); });
    window.addEventListener('blur', function () { for (const k in keys) keys[k] = false; recompute(); });

    const gl = document.getElementById('gl');
    gl.addEventListener('mousedown', function (e) { mouseDown = true; lastX = e.clientX; lastY = e.clientY; });
    window.addEventListener('mouseup', function () { mouseDown = false; });
    window.addEventListener('mousemove', function (e) {
      if (!mouseDown || !I.active) return;
      look(e.clientX - lastX, e.clientY - lastY); lastX = e.clientX; lastY = e.clientY;
    });
    gl.addEventListener('wheel', function (e) { I.dist = Math.min(11, Math.max(3.2, I.dist + e.deltaY * 0.004)); }, { passive: true });

    // ---- touch ----
    const app = document.getElementById('app');
    app.addEventListener('touchstart', function (e) {
      if (!I.active) return;
      for (let i = 0; i < e.changedTouches.length; i++) {
        const t = e.changedTouches[i];
        if (t.target.closest && t.target.closest('button')) continue;
        if (t.clientX < window.innerWidth * 0.5 && !joy) {
          joy = { id: t.identifier, x: t.clientX, y: t.clientY };
          stickEl.style.display = 'block'; knobEl.style.display = 'block';
          stickEl.style.left = (t.clientX - 64) + 'px'; stickEl.style.top = (t.clientY - 64) + 'px';
          knobEl.style.left = (t.clientX - 28) + 'px'; knobEl.style.top = (t.clientY - 28) + 'px';
        } else if (!cam) { cam = { id: t.identifier, x: t.clientX, y: t.clientY }; }
      }
    }, { passive: false });
    app.addEventListener('touchmove', function (e) {
      if (!I.active) return;
      e.preventDefault();
      for (let i = 0; i < e.changedTouches.length; i++) {
        const t = e.changedTouches[i];
        if (joy && t.identifier === joy.id) {
          let dx = t.clientX - joy.x, dy = t.clientY - joy.y; const l = Math.hypot(dx, dy);
          const k = l > R ? R / l : 1; dx *= k; dy *= k;
          I.ix = dx / R; I.iy = -dy / R;
          I.run = Math.min(1, l / R) > 0.92 || runBtn;
          knobEl.style.left = (joy.x + dx - 28) + 'px'; knobEl.style.top = (joy.y + dy - 28) + 'px';
        } else if (cam && t.identifier === cam.id) {
          look(t.clientX - cam.x, t.clientY - cam.y); cam.x = t.clientX; cam.y = t.clientY;
        }
      }
    }, { passive: false });
    function end(e) {
      for (let i = 0; i < e.changedTouches.length; i++) {
        const id = e.changedTouches[i].identifier;
        if (joy && id === joy.id) { joy = null; I.ix = I.iy = 0; I.run = runBtn; stickEl.style.display = knobEl.style.display = 'none'; recompute(); }
        if (cam && id === cam.id) cam = null;
      }
    }
    app.addEventListener('touchend', end); app.addEventListener('touchcancel', end);

    const rb = document.getElementById('btnRun');
    if (rb) {
      const set = function (v) { return function (e) { e.preventDefault(); runBtn = v; rb.classList.toggle('on', v); if (!joy) I.run = v; }; };
      rb.addEventListener('touchstart', set(true), { passive: false }); rb.addEventListener('touchend', set(false)); rb.addEventListener('touchcancel', set(false));
    }
    const cb = document.getElementById('btnCatch');
    if (cb) cb.addEventListener('touchstart', function (e) { e.preventDefault(); if (I.onCatch) I.onCatch(); }, { passive: false });
    if (cb) cb.addEventListener('click', function () { if (!I.touch && I.onCatch) I.onCatch(); });
  };

  I.reset = function () { joy = cam = null; I.ix = I.iy = 0; I.run = false; for (const k in keys) keys[k] = false; if (stickEl) stickEl.style.display = knobEl.style.display = 'none'; };
  window.Input = I;
})();
