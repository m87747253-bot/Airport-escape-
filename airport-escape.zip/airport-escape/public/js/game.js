/* AIRPORT ESCAPE - main client: rendering loop, local player physics, camera, networking glue. */
(function () {
  'use strict';
  const C = SHARED, $ = function (id) { return document.getElementById(id); };
  const isMobile = /Android|iPhone|iPad|iPod|Mobi/i.test(navigator.userAgent) || Input.touch;
  const lowEnd = isMobile || (navigator.hardwareConcurrency || 8) <= 4;
  const QUALITY = lowEnd ? 0.55 : 1;
  const NPC_CAP = 260, MAXP = C.MAX_PLAYERS + 2;

  /* ---------------- renderer / scene ---------------- */
  const canvas = $('gl');
  const renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: !isMobile, powerPreference: 'high-performance' });
  const maxPR = Math.min(window.devicePixelRatio || 1, isMobile ? 1.5 : 2);
  let pr = maxPR;
  renderer.setPixelRatio(pr);
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(62, 1, 0.1, 420);
  function resize() { renderer.setSize(window.innerWidth, window.innerHeight, false); camera.aspect = window.innerWidth / window.innerHeight; camera.updateProjectionMatrix(); }
  window.addEventListener('resize', resize); window.addEventListener('orientationchange', function () { setTimeout(resize, 200); });
  resize();

  const W = World.build(scene);
  const crowd = new Chars.Crowd(scene, NPC_CAP + MAXP); crowd.npcCap = NPC_CAP;
  const npcs = new Chars.NPCs(crowd);
  const avatars = new Chars.Avatars(scene, crowd, NPC_CAP, MAXP);

  /* ---------------- state ---------------- */
  let epoch = Date.now();
  const G = { phase: 'menu', myId: null, team: 'smuggler', players: new Map(), hostId: null, code: '', seed: 0,
    playStart: 0, freezeUntil: 0, roundEnd: 0, alive: true, x: 0, z: 0, ry: 0, anim: 0, stamina: 100, exhausted: false,
    lastSend: 0, lastCatch: 0, spec: 0, remain: 0 };
  function simTime() { return (Net.now() - epoch) / 1000; }
  function angDiff(a, b) { let d = b - a; while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI; return d; }
  npcs.setup(20260, QUALITY);

  /* ---------------- collision ---------------- */
  const R = C.PLAYER_RADIUS, COL = C.COLLIDERS;
  function pushBox(b) {
    if (G.x < b.x1 - R || G.x > b.x2 + R || G.z < b.z1 - R || G.z > b.z2 + R) return;
    const cx = Math.min(Math.max(G.x, b.x1), b.x2), cz = Math.min(Math.max(G.z, b.z1), b.z2);
    const dx = G.x - cx, dz = G.z - cz, d2 = dx * dx + dz * dz;
    if (d2 >= R * R) return;
    if (d2 > 1e-8) { const d = Math.sqrt(d2), k = (R - d) / d; G.x += dx * k; G.z += dz * k; }
    else {
      const l = G.x - b.x1, r = b.x2 - G.x, t = G.z - b.z1, bt = b.z2 - G.z, m = Math.min(l, r, t, bt);
      if (m === l) G.x = b.x1 - R; else if (m === r) G.x = b.x2 + R; else if (m === t) G.z = b.z1 - R; else G.z = b.z2 + R;
    }
  }
  const tb = { x1: 0, z1: 0, x2: 0, z2: 0 };
  function collideAll(t) {
    for (let pass = 0; pass < 2; pass++) {
      for (let i = 0; i < COL.length; i++) pushBox(COL[i]);
      for (let i = 0; i < C.TRAFFIC.length; i++) {
        const v = C.TRAFFIC[i], x = C.trafficPos(v, t);
        tb.x1 = x - v.len / 2; tb.x2 = x + v.len / 2; tb.z1 = v.z - v.wid / 2; tb.z2 = v.z + v.wid / 2; pushBox(tb);
      }
      const B = npcs.bodies;
      for (let i = 0; i < B.length; i++) {
        const n = B[i], dx = G.x - n.x, dz = G.z - n.z;
        if (dx > 1 || dx < -1 || dz > 1 || dz < -1) continue;
        const d2 = dx * dx + dz * dz;
        if (d2 < 0.5 && d2 > 1e-6) { const d = Math.sqrt(d2), k = (0.71 - d) / d; G.x += dx * k; G.z += dz * k; }
      }
    }
    const bd = C.BOUNDS; G.x = Math.min(Math.max(G.x, bd.x1), bd.x2); G.z = Math.min(Math.max(G.z, bd.z1), bd.z2);
  }

  /* ---------------- camera ---------------- */
  const camPos = new THREE.Vector3(), camTarget = new THREE.Vector3();
  function rayClip(ox, oz, dx, dz) {          // fraction (0..1] along the ray before it enters a tall collider
    let f = 1;
    for (let i = 0; i < COL.length; i++) {
      const b = COL[i]; if (b.h < 2.4) continue;
      let t0 = 0, t1 = f, ok = true;
      const o = [ox, oz], d = [dx, dz], lo = [b.x1 - 0.25, b.z1 - 0.25], hi = [b.x2 + 0.25, b.z2 + 0.25];
      for (let a = 0; a < 2; a++) {
        if (Math.abs(d[a]) < 1e-9) { if (o[a] < lo[a] || o[a] > hi[a]) { ok = false; break; } }
        else {
          let ta = (lo[a] - o[a]) / d[a], tb2 = (hi[a] - o[a]) / d[a]; if (ta > tb2) { const s = ta; ta = tb2; tb2 = s; }
          if (ta > t0) t0 = ta; if (tb2 < t1) t1 = tb2; if (t0 > t1) { ok = false; break; }
        }
      }
      if (ok && t0 > 0 && t0 < f) f = t0;
    }
    return f;
  }
  function chaseCamera(tx, tz, dt, snap) {
    const cp = Math.cos(Input.pitch), sp = Math.sin(Input.pitch), dist = Input.dist;
    const dx = Math.sin(Input.yaw) * cp * dist, dz = Math.cos(Input.yaw) * cp * dist;
    const f = Math.max(0.18, rayClip(tx, tz, dx, dz) - 0.04);
    const wx = tx + dx * f, wz = tz + dz * f, wy = Math.max(0.6, 1.5 + sp * dist * Math.max(f, 0.3));
    const k = snap ? 1 : 1 - Math.exp(-16 * dt);
    camPos.x += (wx - camPos.x) * k; camPos.y += (wy - camPos.y) * k; camPos.z += (wz - camPos.z) * k;
    camTarget.set(tx, 1.5, tz);
    camera.position.copy(camPos); camera.lookAt(camTarget);
  }
  function orbitCamera(t, cx, cz, rx, rz, h) {
    const a = t * 0.12;
    camera.position.set(cx + Math.cos(a) * rx, h, cz + Math.sin(a) * rz); camera.lookAt(cx, 1.6, cz);
    camPos.copy(camera.position);
  }

  /* ---------------- screens / networking ---------------- */
  function enterLobby() {
    G.phase = 'lobby'; Input.active = false; Input.reset(); avatars.clear(); HUD.show('lobby');
    $('elim').classList.add('hidden');
  }
  function onLobby(info) {
    G.hostId = info.hostId; G.code = info.code;
    const ids = new Set();
    info.players.forEach(function (p) {
      ids.add(p.id); const o = G.players.get(p.id);
      if (o) { o.name = p.name; o.team = p.team; } else G.players.set(p.id, { id: p.id, name: p.name, team: p.team, alive: true });
    });
    G.players.forEach(function (p, id) { if (!ids.has(id)) { G.players.delete(id); avatars.remove(id); } });
    const idle = G.phase === 'menu' || G.phase === 'lobby' || G.phase === 'results';
    if (idle && info.seed !== G.seed) { G.seed = info.seed; epoch = info.epoch; npcs.setup(G.seed, QUALITY); }
    if (G.phase === 'lobby' || (G.phase === 'results' && info.phase === 'lobby')) { if (G.phase !== 'lobby') enterLobby(); HUD.renderLobby(info, G.myId); }
    if (G.phase === 'lobby') HUD.renderLobby(info, G.myId);
    if (G.phase === 'playing' || G.phase === 'countdown') { G.players.forEach(function (p) { p.alive = p.alive !== false; }); }
  }

  Net.on('lobby', onLobby);
  Net.on('toast', function (m) { HUD.toast(m); });
  Net.on('miss', function () { HUD.toast('No smuggler within reach!'); });
  Net.on('fix', function (a) { G.x = a[0]; G.z = a[1]; });
  Net.on('disconnect', function () {
    if (G.phase === 'menu') return;
    G.phase = 'menu'; Input.active = false; Input.reset(); avatars.clear(); G.players.clear(); HUD.show('menu');
    $('menuErr').textContent = 'Disconnected from the server. Press JOIN GAME to reconnect.';
  });
  Net.on('round', function (d) {
    G.seed = d.seed; epoch = d.epoch; G.playStart = d.playStart; G.freezeUntil = d.freezeUntil; G.roundEnd = d.roundEnd; G.hostId = d.hostId;
    G.players.clear(); avatars.clear();
    d.players.forEach(function (p) {
      G.players.set(p.id, { id: p.id, name: p.name, team: p.team, alive: true });
      const av = avatars.add(p.id, p.name, p.team, p.id === G.myId), sp = d.spawns[p.id];
      if (av && sp) { av.x = sp[0]; av.z = sp[1]; av.ry = sp[2]; }
      if (p.id === G.myId && sp) { G.team = p.team; G.x = sp[0]; G.z = sp[1]; G.ry = sp[2]; }
    });
    npcs.setup(G.seed, QUALITY);
    G.alive = true; G.stamina = C.STAMINA.max; G.exhausted = false; G.anim = 0; G.spec = 0; G.phase = 'countdown';
    G.remain = 0; G.players.forEach(function (p) { if (p.team === 'smuggler') G.remain++; });
    Input.reset(); Input.active = true; Input.yaw = G.team === 'police' ? 0 : Math.PI; Input.pitch = 0.38;
    chaseCamera(G.x, G.z, 0, true);
    if (document.activeElement && document.activeElement.blur) document.activeElement.blur();
    HUD.show('hud'); HUD.setTeam(G.team); HUD.clearFeed(); HUD.setRemain(G.remain); HUD.setTime(C.ROUND_MS / 1000);
    $('elim').classList.add('hidden');
    $('btnRun').classList.toggle('hidden', !Input.touch);
    $('btnCatch').classList.toggle('hidden', G.team !== 'police' || !Input.touch);
    $('btnAgain').disabled = false;
  });
  Net.on('snap', function (d) {
    for (let i = 0; i < d.p.length; i++) {
      const a = d.p[i]; if (a[0] === G.myId) continue;
      avatars.pushSnap(a[0], d.t, a[1], a[2], a[3], a[4], a[5]);
      const p = G.players.get(a[0]); if (p) p.alive = !!a[5];
    }
  });
  Net.on('cap', function (d) {
    const p = G.players.get(d.id); if (p) p.alive = false;
    const av = avatars.map.get(d.id); if (av) { av.alive = false; av.anim = 0; }
    G.remain = d.left; HUD.setRemain(G.remain);
    HUD.feed(d.byName + ' caught ' + d.name + '!', '#ffd54f');
    if (d.id === G.myId) {
      G.alive = false; G.anim = 0; Input.reset(); $('elim').classList.remove('hidden'); $('btnCatch').classList.add('hidden'); HUD.banner('CAUGHT!<small>You were arrested by ' + d.byName + '</small>');
      setTimeout(function () { if (G.phase === 'playing') HUD.banner(''); }, 2200);
    } else if (d.by === G.myId) HUD.toast('Suspect captured: ' + d.name);
  });
  Net.on('end', function (d) {
    G.phase = 'results'; Input.active = false; Input.reset(); HUD.banner('');
    HUD.renderResults(d, G.team, G.myId); HUD.show('results'); $('btnAgain').disabled = false;
  });

  /* ---------------- UI buttons ---------------- */
  $('inName').value = localStorage.getItem('ae_name') || '';
  $('inRoom').value = (new URLSearchParams(location.search).get('room') || localStorage.getItem('ae_room') || '').toUpperCase();
  async function doJoin() {
    const name = $('inName').value.trim() || 'Agent' + ((Math.random() * 90 + 10) | 0), room = $('inRoom').value.trim() || 'MAIN';
    $('menuErr').textContent = 'Connecting...'; $('btnJoin').disabled = true;
    Net.connect();
    const res = await Net.join(name, room);
    $('btnJoin').disabled = false;
    if (!res.ok) { $('menuErr').textContent = res.err || 'Could not join'; return; }
    localStorage.setItem('ae_name', name); localStorage.setItem('ae_room', res.lobby.code);
    $('menuErr').textContent = ''; G.myId = res.id; G.players.clear();
    G.phase = 'lobby'; G.seed = -1; onLobby(res.lobby); HUD.show('lobby');
    history.replaceState(null, '', '?room=' + res.lobby.code);
  }
  $('btnJoin').addEventListener('click', doJoin);
  $('inName').addEventListener('keydown', function (e) { if (e.key === 'Enter') doJoin(); });
  $('inRoom').addEventListener('keydown', function (e) { if (e.key === 'Enter') doJoin(); });
  $('btnPolice').addEventListener('click', function () { Net.emit('team', 'police'); });
  $('btnSmuggler').addEventListener('click', function () { Net.emit('team', 'smuggler'); });
  $('btnStart').addEventListener('click', function () { Net.emit('start'); });
  $('btnAgain').addEventListener('click', function () { $('btnAgain').disabled = true; $('resMsg').textContent = 'Starting a new round...'; Net.emit('restart'); setTimeout(function () { $('btnAgain').disabled = false; }, 2500); });
  $('btnToLobby').addEventListener('click', function () { Net.emit('toLobby'); });
  canvas.addEventListener('click', function () { if (G.phase === 'playing' && !G.alive) G.spec++; });
  Input.init();
  Input.onSpectate = function () { G.spec++; };
  Input.onCatch = function () {
    if (G.team !== 'police' || G.phase !== 'playing' || !G.alive || Net.now() < G.freezeUntil) return;
    const n = performance.now(); if (n - G.lastCatch < 650) return;
    G.lastCatch = n; Net.emit('catch');
  };

  /* ---------------- per-frame logic ---------------- */
  let lastSend = 0, hudT = 0, mapT = 0, frames = 0, frameAcc = 0;
  const focus = { x: 0, z: 0 };

  function updateLocal(dt, now, t) {
    const canMove = G.phase === 'playing' && G.alive && !(G.team === 'police' && now < G.freezeUntil);
    let mode = 0;
    if (canMove) {
      const mag = Math.min(1, Math.hypot(Input.ix, Input.iy));
      let running = false;
      if (mag > 0.12) {
        const sy = Math.sin(Input.yaw), cy = Math.cos(Input.yaw);
        let dx = -sy * Input.iy + cy * Input.ix, dz = -cy * Input.iy - sy * Input.ix; const l = Math.hypot(dx, dz); dx /= l; dz /= l;
        if (G.exhausted && G.stamina >= C.STAMINA.minStart) G.exhausted = false;
        running = Input.run && !G.exhausted && G.stamina > 0;
        if (running) { G.stamina -= C.STAMINA.drain * dt; if (G.stamina <= 0) { G.stamina = 0; G.exhausted = true; } }
        let sp = running ? C.RUN : C.WALK * Math.max(0.6, mag);
        if (G.team === 'police') sp *= C.POLICE_BONUS;
        G.x += dx * sp * dt; G.z += dz * sp * dt;
        G.ry += angDiff(G.ry, Math.atan2(dx, dz)) * Math.min(1, dt * 14);
        mode = running ? 2 : 1;
      }
      if (!running) { G.stamina = Math.min(C.STAMINA.max, G.stamina + C.STAMINA.regen * dt); if (G.exhausted && G.stamina >= C.STAMINA.minStart) G.exhausted = false; }
      collideAll(t);
      if (now - lastSend > 62) { lastSend = now; Net.emit('st', [+G.x.toFixed(2), +G.z.toFixed(2), +G.ry.toFixed(2), mode]); }
    }
    G.anim = mode;
    avatars.setLocal(G.myId, G.x, G.z, G.ry, G.alive ? mode : 0, dt);
  }

  function updateHud(now, t) {
    const frac = G.stamina / C.STAMINA.max; HUD.stamina(frac, G.exhausted);
    if (now - hudT > 200) {
      hudT = now;
      if (G.phase === 'countdown') {
        HUD.setTime(C.ROUND_MS / 1000);
        HUD.banner(Math.max(1, Math.ceil((G.playStart - now) / 1000)) + '<small>Get ready - ' + (G.team === 'police' ? 'you are POLICE' : 'you are a SMUGGLER') + '</small>');
      } else if (G.phase === 'playing') {
        HUD.setTime((G.roundEnd - now) / 1000);
        if (now < G.playStart + 1200) HUD.banner('GO!');
        else if (G.alive && now < G.freezeUntil) HUD.banner(G.team === 'police' ? 'Released in ' + Math.ceil((G.freezeUntil - now) / 1000) + '<small>Smugglers have a head start!</small>' : '');
        else if (G.alive) HUD.banner('');
      }
      if (G.team === 'smuggler') {
        const ex = (C.EXIT.x1 + C.EXIT.x2) / 2, ez = (C.EXIT.z1 + C.EXIT.z2) / 2;
        HUD.objective('Reach the green EXIT zone in the parking lot — ' + Math.round(Math.hypot(G.x - ex, G.z - ez)) + ' m');
      } else HUD.objective('Catch every smuggler before they escape! Get close, then press CATCH (Space)');
      if (G.team === 'police' && G.phase === 'playing') {
        let near = false;
        avatars.map.forEach(function (av) { if (av.team === 'smuggler' && av.alive && Math.hypot(av.x - G.x, av.z - G.z) <= C.CATCH_RANGE) near = true; });
        $('btnCatch').classList.toggle('ready', near);
      }
    }
    if (now - mapT > 100) {
      mapT = now; const list = [];
      avatars.map.forEach(function (av) { list.push({ x: av.x, z: av.z, team: av.team, alive: av.alive, me: av.me }); });
      HUD.minimap(list, t);
    }
  }

  let last = performance.now();
  function frame(ts) {
    requestAnimationFrame(frame);
    const dt = Math.min(0.05, (ts - last) / 1000); last = ts;
    const now = Net.now(), t = simTime();
    if (G.phase === 'countdown' && now >= G.playStart) G.phase = 'playing';
    const inGame = G.phase === 'countdown' || G.phase === 'playing';

    if (inGame) {
      updateLocal(dt, now, t);
      focus.x = G.x; focus.z = G.z;
      if (G.alive) chaseCamera(G.x, G.z, dt, false);
      else {
        const list = []; avatars.map.forEach(function (av) { if (!av.me && av.alive) list.push(av); });
        if (list.length) { const av = list[G.spec % list.length]; chaseCamera(av.x, av.z, dt, false); } else chaseCamera(G.x, G.z, dt, false);
      }
      updateHud(now, t);
    } else if (G.phase === 'results') {
      focus.x = G.x; focus.z = G.z; orbitCamera(t, G.x, G.z, 9, 9, 4.5);
    } else {
      focus.x = 999; focus.z = 999; orbitCamera(t, 0, 6, 24, 14, 6.5);
    }
    for (let i = 0; i < W.anim.length; i++) W.anim[i](t);
    npcs.update(t, dt, inGame || G.phase === 'results' ? focus : null);
    avatars.update(now, dt, t);
    crowd.flush();
    renderer.render(scene, camera);

    frameAcc += dt; frames++;                           // adaptive resolution for weak phones
    if (frames >= 45) {
      const avg = frameAcc / frames; frames = 0; frameAcc = 0;
      if (avg > 0.028 && pr > 0.75) { pr = Math.max(0.75, pr - 0.15); renderer.setPixelRatio(pr); resize(); }
      else if (avg < 0.0185 && pr < maxPR) { pr = Math.min(maxPR, pr + 0.1); renderer.setPixelRatio(pr); resize(); }
    }
  }
  requestAnimationFrame(frame);
  window.__game = { G: G, npcs: npcs, avatars: avatars, scene: scene, camera: camera, renderer: renderer };   // handy for debugging in the console
})();
