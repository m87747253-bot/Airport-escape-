/* AIRPORT ESCAPE - terminal interior: security, check-in, gates, shops, food court, signage. */
(function () {
  'use strict';
  World.interior = function (ctx) {
    const C = ctx.C, sign = ctx.sign;
    const A = ctx.B('airside'), H = ctx.B('hall'), X = ctx.B('ext');

    C.COLLIDERS.forEach(function (c) {
      const cx = (c.x1 + c.x2) / 2, cz = (c.z1 + c.z2) / 2, w = c.x2 - c.x1, d = c.z2 - c.z1;
      switch (c.kind) {
        case 'secwall':
          H.rect(c.x1, 0, c.z1, c.x2, c.h, c.z2, 0x78909c);
          H.rect(c.x1, c.h - 0.4, c.z1 - 0.05, c.x2, c.h, c.z2 + 0.05, 0x1e88e5);
          H.g.rect(c.x1, c.h, c.z1, c.x2, c.h + 3, c.z2, 0x9fd8ff);
          break;
        case 'xray': {
          H.rect(c.x1, 0, c.z1, c.x2, c.h, c.z2, 0x455a64);
          H.rect(c.x1 + 0.2, c.h, c.z1 + 0.2, c.x2 - 0.2, c.h + 0.9, c.z2 - 0.2, 0x263238);
          H.e.rect(c.x1 + 0.4, c.h + 0.9, c.z1 + 0.4, c.x2 - 0.4, c.h + 0.95, c.z2 - 0.4, 0x4caf50);
          break;
        }
        case 'counter': {
          H.rect(c.x1, 0, c.z1, c.x2, 1.0, c.z2, 0x1565c0);
          H.rect(c.x1 - 0.1, 1.0, c.z1 - 0.1, c.x2 + 0.1, 1.15, c.z2 + 0.1, 0xeceff1);
          [-2.5, 0, 2.5].forEach(function (k) {
            H.rect(cx + k - 0.3, 1.15, cz - 0.15, cx + k + 0.3, 1.65, cz + 0.05, 0x263238);
            H.e.rect(cx + k - 0.25, 1.2, cz - 0.151, cx + k + 0.25, 1.6, cz - 0.15, 0x80d8ff);
          });
          const idx = C.COUNTER_X.indexOf(c.cx) + 1;
          H.rect(c.cx - 0.05, 4.6, cz - 0.05, c.cx + 0.05, 10, cz + 0.05, 0x607d8b);
          sign([(c.row ? 'CHECK-IN B' : 'CHECK-IN A') + idx], 4.2, 1.0, c.cx, 4.6, cz, 0, c.row ? '#00695c' : '#1565c0');
          break;
        }
        case 'desk': {
          A.rect(c.x1, 0, c.z1, c.x2, 1.0, c.z2, 0x00796b);
          A.rect(c.x1 - 0.1, 1.0, c.z1 - 0.1, c.x2 + 0.1, 1.12, c.z2 + 0.1, 0xffffff);
          A.rect(cx - 0.4, 1.12, cz - 0.15, cx + 0.4, 1.7, cz + 0.05, 0x263238);
          A.e.rect(cx - 0.35, 1.17, cz + 0.051, cx + 0.35, 1.65, cz + 0.055, 0x80d8ff);
          sign(['GATE A' + (c.gate + 1), 'NOW BOARDING'], 5, 1.6, cx, 5.2, cz + 0.6, 0, '#0d47a1');
          A.rect(cx - 0.05, 6, cz + 0.55, cx + 0.05, 10, cz + 0.65, 0x607d8b);
          break;
        }
        case 'bench': {
          const grp = c.z1 < 0 ? A : H, col = c.z1 < 0 ? 0x3949ab : 0x00897b;
          grp.rect(c.x1, 0.38, c.z1, c.x2, 0.5, c.z2, col);
          grp.rect(c.x1, 0.5, c.z2 - 0.18, c.x2, 1.15, c.z2, col);
          for (let x = c.x1 + 0.3; x < c.x2; x += 2.5) grp.rect(x, 0, c.z1 + 0.1, x + 0.12, 0.38, c.z2 - 0.1, 0x37474f);
          break;
        }
        case 'table':
          A.cyl(cx, 0.4, cz, 0.05, 0.05, 0.8, 6, 0x546e7a);
          A.cyl(cx, 0.82, cz, 0.85, 0.85, 0.07, 8, 0xfff3e0);
          break;
        case 'kiosk':
          A.rect(c.x1, 0, c.z1, c.x2, 2.0, c.z2, 0x37474f);
          A.rect(c.x1 - 0.1, 2.0, c.z1 - 0.1, c.x2 + 0.1, 2.6, c.z2 + 0.1, 0x1565c0);
          A.e.rect(c.x1 + 0.2, 0.9, c.z1 - 0.02, c.x2 - 0.2, 1.8, c.z1 - 0.01, 0x80d8ff);
          A.e.rect(c.x1 + 0.2, 0.9, c.z2 + 0.01, c.x2 - 0.2, 1.8, c.z2 + 0.02, 0x80d8ff);
          sign('INFO', 2, 0.6, cx, 3.2, cz, 0, '#ffb300', '#212121');
          break;
        case 'pillar':
          X.rect(c.x1, 0, c.z1, c.x2, c.h, c.z2, 0xf5f5f5);
          X.rect(c.x1 - 0.1, 0, c.z1 - 0.1, c.x2 + 0.1, 0.8, c.z2 + 0.1, 0x1e88e5);
          break;
        case 'planter':
          X.rect(c.x1, 0, c.z1, c.x2, 0.9, c.z2, 0x8d6e63);
          X.cyl(cx, 1.0 + 1.6, cz, 0, 1.05, 3.2, 6, 0x388e3c);
          X.cyl(cx, 1.0 + 0.4, cz, 0.15, 0.15, 0.8, 5, 0x5d4037);
          break;
        case 'shop': buildShop(c); break;
      }
    });

    // chairs at the food-court tables
    C.SEATS.forEach(function (s) {
      if (s.z < -14 || s.z > -9) return;
      const fx = Math.sin(s.ry), fz = Math.cos(s.ry);
      A.rect(s.x - 0.25, 0.4, s.z - 0.25, s.x + 0.25, 0.48, s.z + 0.25, 0xff7043);
      const alongX = Math.abs(fx) > Math.abs(fz);
      A.box(s.x - fx * 0.27, 0.74, s.z - fz * 0.27, alongX ? 0.06 : 0.5, 0.52, alongX ? 0.5 : 0.06, 0xff7043);
      A.rect(s.x - 0.04, 0, s.z - 0.04, s.x + 0.04, 0.4, s.z + 0.04, 0x455a64);
    });

    function buildShop(c) {
      const s = c.shop, f = s.side < 0 ? 1 : -1;               // f: direction of the open front (+1 = +x)
      const front = s.side < 0 ? s.x2 : s.x1, back = s.side < 0 ? s.x1 : s.x2, t = 0.25;
      const cz = (s.z1 + s.z2) / 2;
      A.rect(s.x1, 0, s.z1, s.x2, 0.1, s.z2, 0xd7ccc8);                                  // floor
      A.rect(Math.min(back, back + f * t), 0, s.z1, Math.max(back, back + f * t), 4.2, s.z2, 0xfafafa);   // back wall
      A.rect(s.x1, 0, s.z1, s.x2, 4.2, s.z1 + t, 0xfafafa);                              // side walls
      A.rect(s.x1, 0, s.z2 - t, s.x2, 4.2, s.z2, 0xfafafa);
      A.rect(s.x1, 4.2, s.z1, s.x2, 4.4, s.z2, s.color);                                 // roof
      const fx0 = Math.min(front, front - f * 0.1), fx1 = Math.max(front, front - f * 0.1);
      A.g.rect(fx0, 0.1, s.z1 + t, fx1, 3.6, s.z2 - t, 0xb3e5fc);                        // glass front
      A.rect(fx0 - 0.05, 3.5, s.z1, fx1 + 0.05, 4.4, s.z2, s.color);                     // sign band
      A.rect(Math.min(front, front + f * 1.1), 3.3, s.z1, Math.max(front, front + f * 1.1), 3.5, s.z2, s.color);   // awning
      sign(s.name, 4.6, 0.8, front + f * 0.06, 3.95, cz, f > 0 ? Math.PI / 2 : -Math.PI / 2, '#' + ('000000' + s.color.toString(16)).slice(-6));
      // interior: shelves + counter + goods
      for (let k = 0; k < 4; k++) {
        const sz = s.z1 + 0.8 + k * 1.1;
        A.rect(back + f * 0.25, 0.1, sz, back + f * 1.0, 2.0, sz + 0.12, 0x8d6e63);
        for (let j = 0; j < 4; j++) A.rect(back + f * 0.3, 0.3 + j * 0.45, sz, back + f * 0.9, 0.55 + j * 0.45, sz + 0.1, [0xef5350, 0x66bb6a, 0xffca28, 0x42a5f5][(j + k) % 4]);
      }
      A.rect(front - f * 1.8, 0.1, s.z1 + 0.6, front - f * 1.0, 1.0, s.z2 - 0.6, 0x5d4037);
      A.e.rect(Math.min(front, front - f * 0.2), 3.2, s.z1 + t, Math.max(front, front - f * 0.2), 3.3, s.z2 - t, 0xfffde7);
    }

    // ----- scanner arches, lane signs, security & orientation signage -----
    C.LANES.forEach(function (gx, i) {
      H.rect(gx - 1.3, 0, -1.2, gx - 1.1, 2.6, -0.8, 0x90a4ae); H.rect(gx + 1.1, 0, -1.2, gx + 1.3, 2.6, -0.8, 0x90a4ae);
      H.rect(gx - 1.3, 2.5, -1.2, gx + 1.3, 2.75, -0.8, 0x90a4ae);
      H.e.rect(gx - 1.05, 0.1, -1.05, gx - 1.0, 2.5, -0.95, 0x4caf50); H.e.rect(gx + 1.0, 0.1, -1.05, gx + 1.05, 2.5, -0.95, 0x4caf50);
      sign('LANE ' + (i + 1), 3.2, 0.8, gx, 5.2, -3.5, 0, '#37474f');
      H.rect(gx - 0.04, 5.6, -3.54, gx + 0.04, 10, -3.46, 0x607d8b);
    });
    sign(['SECURITY CHECK', 'AIRSIDE >>'], 11, 2.2, 0, 7.4, -3.5, 0, '#c62828');
    sign(['GATES A1 - A6', 'BOARDING >>'], 10, 2.2, 0, 7.6, -16.5, 0, '#0d47a1');
    sign(['EXIT  >>', 'TAXI  •  PARKING'], 9, 2.0, 0, 6.4, 29.5, 0, '#2e7d32');
    [-30, 30].forEach(function (x) {
      sign(['DEPARTURES', 'SK 401  DUBAI    ON TIME', 'AI 233  DELHI    GATE A3', 'BA 117  LONDON   DELAYED', 'EK 502  PARIS    BOARDING'], 9, 4, x, 7.4, -8.5, 0, '#0b1d3a', '#ffd54f');
    });
    sign(['CHECK-IN', 'DESKS A & B'], 8, 1.8, -30, 6.5, 6, 0, '#1565c0');
    sign(['CHECK-IN', 'DESKS A & B'], 8, 1.8, 30, 6.5, 6, 0, '#1565c0');
    // rows of ceiling-mounted lamps are baked into the roof; add queue stanchions in the aisle
    C.COUNTER_X.forEach(function (cx) {
      [14.3, 18.7].forEach(function (z) {
        for (let k = -3; k <= 3; k += 3) { H.rect(cx + k - 0.05, 0, z - 0.05, cx + k + 0.05, 0.9, z + 0.05, 0xb71c1c); }
        H.rect(cx - 3, 0.75, z - 0.02, cx + 3, 0.8, z + 0.02, 0xef5350);
      });
    });
  };
})();
