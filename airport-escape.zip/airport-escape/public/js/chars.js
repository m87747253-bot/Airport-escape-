/* AIRPORT ESCAPE - low-poly characters.
 * ALL characters (NPCs + players) are drawn by ONE InstancedMesh (10 box parts each) = a single draw call. */
(function () {
  'use strict';
  const C = SHARED;
  const PARTS = 10;           // 0 lLeg 1 rLeg 2 torso 3 lArm 4 rArm 5 head 6 hair 7 hat 8 accessory 9 vest/badge
  // [pivotX, pivotY, pivotZ, sizeX, sizeY, sizeZ, isLimb]
  const DEF = [
    [-0.15, 0.85, 0, 0.27, 0.85, 0.3, 1], [0.15, 0.85, 0, 0.27, 0.85, 0.3, 1],
    [0, 1.23, 0, 0.62, 0.76, 0.36, 0],
    [-0.41, 1.55, 0, 0.2, 0.7, 0.24, 1], [0.41, 1.55, 0, 0.2, 0.7, 0.24, 1],
    [0, 1.84, 0, 0.38, 0.38, 0.38, 0], [0, 2.0, -0.02, 0.4, 0.14, 0.42, 0],
    [0, 2.06, 0.03, 0.43, 0.13, 0.5, 0], null, [0, 1.2, 0, 0.66, 0.4, 0.4, 0]
  ];
  const ACC = { suit: [0.62, 0.42, 0.02, 0.18, 0.5, 0.34], pack: [0, 1.28, -0.3, 0.46, 0.55, 0.22], duffel: [0, 1.2, -0.33, 0.52, 0.5, 0.3] };
  const _col = new THREE.Color();

  function put(arr, o, X, Y, Z, c, s, S, px, py, pz, ang, sx, sy, sz, limb) {
    let ca = 1, sa = 0;
    if (ang) { ca = Math.cos(ang); sa = Math.sin(ang); }
    let qy = py, qz = pz;
    if (limb) { qy = py - sy * 0.5 * ca; qz = pz - sy * 0.5 * sa; }
    arr[o] = c * sx * S; arr[o + 1] = 0; arr[o + 2] = -s * sx * S; arr[o + 3] = 0;
    arr[o + 4] = s * sy * sa * S; arr[o + 5] = sy * ca * S; arr[o + 6] = c * sy * sa * S; arr[o + 7] = 0;
    arr[o + 8] = s * sz * ca * S; arr[o + 9] = -sz * sa * S; arr[o + 10] = c * sz * ca * S; arr[o + 11] = 0;
    arr[o + 12] = X + S * (c * px + s * qz); arr[o + 13] = Y + S * qy; arr[o + 14] = Z + S * (-s * px + c * qz); arr[o + 15] = 1;
  }
  function hide(arr, o) { for (let k = 0; k < 16; k++) arr[o + k] = 0; arr[o + 15] = 1; }

  /* ---------------- Crowd: the instanced renderer ---------------- */
  function Crowd(scene, cap) {
    this.cap = cap;
    this.mesh = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), new THREE.MeshLambertMaterial(), cap * PARTS);
    this.mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.mesh.frustumCulled = false;
    this.arr = this.mesh.instanceMatrix.array;
    this.cfg = new Array(cap);
    for (let i = 0; i < cap * PARTS; i++) { this.mesh.setColorAt(i, _col.set(0xffffff)); hide(this.arr, i * 16); }
    scene.add(this.mesh);
  }
  Crowd.prototype.setLook = function (i, L) {
    const m = this.mesh;
    function col(p, hex) { m.setColorAt(i * PARTS + p, _col.set(hex)); }
    col(0, L.pants); col(1, L.pants); col(2, L.shirt);
    col(3, L.sleeveSkin ? L.skin : L.shirt); col(4, L.sleeveSkin ? L.skin : L.shirt);
    col(5, L.skin); col(6, L.hair); col(7, L.hat != null ? L.hat : L.hair);
    col(8, L.acc ? L.acc.color : 0xffffff); col(9, L.vest != null ? L.vest : 0xffffff);
    this.cfg[i] = { S: L.scale || 1, hat: L.hat != null, acc: L.acc ? L.acc.kind : null, vest: L.vest != null };
    m.instanceColor.needsUpdate = true;
  };
  Crowd.prototype.hideChar = function (i) { for (let p = 0; p < PARTS; p++) hide(this.arr, (i * PARTS + p) * 16); };
  /* mode: 0 idle, 1 walk, 2 run, 3 sit, 4 cuffed */
  Crowd.prototype.pose = function (i, x, y, z, ry, phase, mode, t) {
    const cf = this.cfg[i]; if (!cf) return;
    const S = cf.S, c = Math.cos(ry), s = Math.sin(ry), a = this.arr, b = i * PARTS * 16;
    let lL = 0, rL = 0, lA = 0, rA = 0, bob = 0, sw;
    if (mode === 1) { sw = Math.sin(phase); lL = sw * 0.7; rL = -lL; lA = -sw * 0.6; rA = -lA; bob = Math.abs(Math.cos(phase)) * 0.045; }
    else if (mode === 2) { sw = Math.sin(phase); lL = sw * 1.05; rL = -lL; lA = -sw * 1.25; rA = -lA; bob = Math.abs(Math.cos(phase)) * 0.09; }
    else if (mode === 3) { lL = rL = -1.5; lA = rA = -0.75; bob = -0.36; }
    else if (mode === 4) { lA = rA = -1.2; }
    else { lA = Math.sin(t * 1.4 + i * 1.7) * 0.05; rA = -lA; }
    const Y = y + bob * S;
    const L = (o, k, ang) => put(a, b + o * 16, x, Y, z, c, s, S, DEF[k][0], DEF[k][1], DEF[k][2], ang, DEF[k][3], DEF[k][4], DEF[k][5], DEF[k][6]);
    L(0, 0, lL); L(1, 1, rL); L(2, 2, 0); L(3, 3, lA); L(4, 4, rA); L(5, 5, 0); L(6, 6, 0);
    if (cf.hat) L(7, 7, 0); else hide(a, b + 7 * 16);
    if (cf.acc) { const A = ACC[cf.acc]; put(a, b + 8 * 16, x, Y, z, c, s, S, A[0], A[1], A[2], 0, A[3], A[4], A[5], 0); } else hide(a, b + 8 * 16);
    if (cf.vest) L(9, 9, 0); else hide(a, b + 9 * 16);
  };
  Crowd.prototype.flush = function () { this.mesh.instanceMatrix.needsUpdate = true; };

  /* ---------------- NPC crowd: deterministic paths + cosmetic avoidance ---------------- */
  function NPCs(crowd) { this.crowd = crowd; this.list = []; this.bodies = []; this.tmp = { x: 0, z: 0, ry: 0, s: 0 }; this.grid = new Map(); }
  NPCs.prototype.setup = function (seed, quality) {
    for (let i = 0; i < this.list.length; i++) this.crowd.hideChar(i);
    this.list = C.generateNPCs(seed, quality);
    if (this.list.length > this.crowd.npcCap) this.list.length = this.crowd.npcCap;
    this.walkers = [];
    this.list.forEach((n, i) => {
      n.slot = i; n.ox = 0; n.oz = 0; n.h = 0; n.hInit = false;
      this.crowd.setLook(i, n.look);
      if (n.type === 'walk') this.walkers.push(n);
    });
    this.bodies = this.list.filter(n => n.type !== 'sit');
  };
  function angDiff(a, b) { let d = b - a; while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI; return d; }
  /* t: shared clock (s). focus: {x,z} camera focus used for animation LOD and player avoidance */
  NPCs.prototype.update = function (t, dt, focus) {
    const W = this.walkers, tmp = this.tmp, grid = this.grid, crowd = this.crowd;
    grid.clear();
    for (let i = 0; i < W.length; i++) {          // pass 1: path positions + spatial hash
      const n = W[i]; C.walkerPose(n, t, tmp);
      n.bx = tmp.x; n.bz = tmp.z; n.tr = tmp.ry; n.ph = tmp.s * 3.4;
      const key = ((n.bx / 1.5) | 0) * 512 + ((n.bz / 1.5) | 0);
      let cell = grid.get(key); if (!cell) { cell = []; grid.set(key, cell); } cell.push(n);
    }
    for (let i = 0; i < W.length; i++) {          // pass 2: separation from neighbours and from the focus player
      const n = W[i]; let px = 0, pz = 0;
      const cx = (n.bx / 1.5) | 0, cz = (n.bz / 1.5) | 0;
      for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) {
        const cell = grid.get((cx + dx) * 512 + (cz + dz)); if (!cell) continue;
        for (let k = 0; k < cell.length; k++) {
          const o = cell[k]; if (o === n) continue;
          const ddx = n.bx - o.bx, ddz = n.bz - o.bz, d2 = ddx * ddx + ddz * ddz;
          if (d2 < 0.64 && d2 > 1e-6) { const d = Math.sqrt(d2), f = (0.8 - d) * 0.6; px += ddx / d * f; pz += ddz / d * f; }
        }
      }
      if (focus) {
        const ddx = n.bx - focus.x, ddz = n.bz - focus.z, d2 = ddx * ddx + ddz * ddz;
        if (d2 < 2.56 && d2 > 1e-6) { const d = Math.sqrt(d2), f = (1.6 - d) * 0.9; px += ddx / d * f; pz += ddz / d * f; }
      }
      const k = Math.min(1, dt * 6); n.ox += (px - n.ox) * k; n.oz += (pz - n.oz) * k;
      if (!n.hInit) { n.h = n.tr; n.hInit = true; } else n.h += angDiff(n.h, n.tr) * Math.min(1, dt * 7);
      n.x = n.bx + n.ox; n.z = n.bz + n.oz;
      let mode = 1;
      if (focus) { const fx = n.x - focus.x, fz = n.z - focus.z; if (fx * fx + fz * fz > 2500) mode = 0; }
      crowd.pose(n.slot, n.x, 0, n.z, n.h, n.ph, mode, t);
    }
    const L = this.list;
    for (let i = 0; i < L.length; i++) {
      const n = L[i];
      if (n.type === 'sit') crowd.pose(n.slot, n.x, 0, n.z, n.ry, 0, 3, t);
      else if (n.type === 'stand') { n.ox = n.ox || 0; crowd.pose(n.slot, n.x, 0, n.z, n.ry, 0, 0, t); }
    }
  };

  /* ---------------- player avatars (local + remote) ---------------- */
  function hash(str) { let h = 2166136261; for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
  function playerLook(id, team) {
    const h = hash(id), r = C.mulberry32(h);
    const L = { skin: C.SKIN[h % C.SKIN.length], hair: C.HAIR[(h >> 3) % C.HAIR.length], sleeveSkin: false, scale: 1, vest: null };
    if (team === 'police') { L.shirt = 0x1e5be0; L.pants = 0x0d1b3d; L.hat = 0x0a2a7a; L.vest = 0xe3f2fd; L.acc = null; }
    else { L.shirt = 0xff6d00; L.pants = 0x222222; L.hat = 0x111111; L.acc = { kind: 'duffel', color: 0xffd600 }; }
    return L;
  }
  function makeLabel(text, color) {
    const cv = document.createElement('canvas'); cv.width = 256; cv.height = 64;
    const x = cv.getContext('2d');
    x.fillStyle = color; x.globalAlpha = 0.88;
    x.beginPath(); x.moveTo(14, 4); x.lineTo(242, 4); x.quadraticCurveTo(252, 4, 252, 14); x.lineTo(252, 50); x.quadraticCurveTo(252, 60, 242, 60); x.lineTo(14, 60); x.quadraticCurveTo(4, 60, 4, 50); x.lineTo(4, 14); x.quadraticCurveTo(4, 4, 14, 4); x.fill();
    x.globalAlpha = 1; x.fillStyle = '#fff'; x.textAlign = 'center'; x.textBaseline = 'middle';
    let fs = 34; x.font = '800 ' + fs + 'px Arial, sans-serif';
    while (x.measureText(text).width > 228 && fs > 12) { fs -= 2; x.font = '800 ' + fs + 'px Arial, sans-serif'; }
    x.fillText(text, 128, 34);
    const tex = new THREE.CanvasTexture(cv);
    const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, depthTest: false, transparent: true }));
    sp.scale.set(2.8, 0.7, 1); sp.renderOrder = 20;
    return sp;
  }

  function Avatars(scene, crowd, firstSlot, maxPlayers) {
    this.scene = scene; this.crowd = crowd; this.first = firstSlot; this.max = maxPlayers;
    this.map = new Map(); this.free = [];
    for (let i = maxPlayers - 1; i >= 0; i--) this.free.push(firstSlot + i);
    this.ringGeo = new THREE.RingGeometry(0.55, 0.78, 20);
  }
  Avatars.prototype.add = function (id, name, team, isMe) {
    this.remove(id);
    const slot = this.free.pop(); if (slot == null) return null;
    const col = team === 'police' ? '#1565c0' : '#e65100';
    const av = { id: id, slot: slot, name: name, team: team, me: !!isMe, alive: true, x: 0, z: 0, ry: 0, anim: 0, phase: 0, buf: [], vis: true };
    this.crowd.setLook(slot, playerLook(id, team));
    av.label = makeLabel((isMe ? '★ ' : '') + name, col); this.scene.add(av.label);
    av.ring = new THREE.Mesh(this.ringGeo, new THREE.MeshBasicMaterial({ color: team === 'police' ? 0x42a5f5 : 0xff9800, transparent: true, opacity: 0.9, depthWrite: false }));
    av.ring.rotation.x = -Math.PI / 2; this.scene.add(av.ring);
    this.map.set(id, av); return av;
  };
  Avatars.prototype.remove = function (id) {
    const av = this.map.get(id); if (!av) return;
    this.crowd.hideChar(av.slot); this.free.push(av.slot);
    this.scene.remove(av.label); this.scene.remove(av.ring); av.label.material.map.dispose(); av.label.material.dispose(); av.ring.material.dispose();
    this.map.delete(id);
  };
  Avatars.prototype.clear = function () { Array.from(this.map.keys()).forEach(id => this.remove(id)); };
  Avatars.prototype.pushSnap = function (id, t, x, z, ry, anim, alive) {
    const av = this.map.get(id); if (!av || av.me) return;
    av.buf.push({ t: t, x: x, z: z, ry: ry, a: anim }); if (av.buf.length > 12) av.buf.shift();
    av.alive = !!alive;
  };
  Avatars.prototype.setLocal = function (id, x, z, ry, anim, dt) {
    const av = this.map.get(id); if (!av) return;
    av.x = x; av.z = z; av.ry = ry; av.anim = anim;
    av.phase += dt * (anim === 2 ? 14 : anim === 1 ? 7.5 : 0);
  };
  /* serverNow: ms server clock; remote players are rendered ~110 ms in the past for smooth interpolation */
  Avatars.prototype.update = function (serverNow, dt, t) {
    const rt = serverNow - 110;
    this.map.forEach(av => {
      if (!av.me) {
        const b = av.buf;
        if (b.length) {
          let i = b.length - 1; while (i > 0 && b[i - 1].t > rt) i--;
          const p1 = b[i], p0 = i > 0 ? b[i - 1] : null;
          if (p0 && rt >= p0.t && p1.t > p0.t) {
            const f = Math.min(1, (rt - p0.t) / (p1.t - p0.t));
            av.x = p0.x + (p1.x - p0.x) * f; av.z = p0.z + (p1.z - p0.z) * f; av.ry = p0.ry + angDiff(p0.ry, p1.ry) * f; av.anim = p1.a;
          } else { av.x = p1.x; av.z = p1.z; av.ry = p1.ry; av.anim = p1.a; }
        }
        av.phase += dt * (av.anim === 2 ? 14 : av.anim === 1 ? 7.5 : 0);
      }
      const mode = !av.alive ? 4 : av.anim;
      this.crowd.pose(av.slot, av.x, 0, av.z, av.ry, av.phase, mode, t);
      av.label.position.set(av.x, 2.55, av.z); av.ring.position.set(av.x, 0.06, av.z);
      av.ring.material.color.setHex(!av.alive ? 0x9e9e9e : av.team === 'police' ? 0x42a5f5 : 0xff9800);
    });
  };

  window.Chars = { Crowd: Crowd, NPCs: NPCs, Avatars: Avatars, PARTS: PARTS };
})();
