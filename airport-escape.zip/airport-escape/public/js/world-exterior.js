/* AIRPORT ESCAPE - exterior: parking lot, traffic, apron planes, exit gate, scenery. */
(function () {
  'use strict';
  World.exterior = function (ctx) {
    const C = ctx.C, scene = ctx.scene, sign = ctx.sign;
    const P = ctx.B('parking'), X = ctx.B('ext'), SKY = ctx.B('scenery'), AP = ctx.B('apron');
    const rnd = C.mulberry32(99);

    // ----- parked cars (these are real colliders) -----
    C.COLLIDERS.forEach(function (c) {
      if (c.kind !== 'car') return;
      const cx = (c.x1 + c.x2) / 2, cz = (c.z1 + c.z2) / 2;
      P.rect(c.x1, 0.3, c.z1, c.x2, 0.95, c.z2, c.color);
      P.rect(cx - 1.2, 0.95, c.z1 + 0.1, cx + 1.1, 1.5, c.z2 - 0.1, 0x37474f);
      P.rect(cx - 1.2, 1.5, c.z1 + 0.15, cx + 1.1, 1.58, c.z2 - 0.15, c.color);
      [[-1.5, c.z1 - 0.05], [1.5, c.z1 - 0.05], [-1.5, c.z2 - 0.2], [1.5, c.z2 - 0.2]].forEach(function (w) {
        P.rect(cx + w[0] - 0.4, 0, w[1], cx + w[0] + 0.4, 0.65, w[1] + 0.25, 0x212121);
      });
      P.e.rect(c.x2 - 0.05, 0.55, c.z1 + 0.15, c.x2, 0.8, c.z1 + 0.5, 0xfff59d);
      P.e.rect(c.x2 - 0.05, 0.55, c.z2 - 0.5, c.x2, 0.8, c.z2 - 0.15, 0xfff59d);
    });

    // ----- lamp posts along the road edge -----
    for (let x = -57; x <= 57; x += 14) {
      X.rect(x - 0.08, 0, 35.2, x + 0.08, 6.5, 35.36, 0x546e7a);
      X.rect(x - 0.08, 6.4, 35.2, x + 0.08, 6.55, 37.2, 0x546e7a);
      X.e.rect(x - 0.35, 6.3, 36.6, x + 0.35, 6.4, 37.2, 0xfff9c4);
    }
    // parking signs and bollards
    sign(['PARKING', 'P1  P2  P3'], 5, 1.5, 0, 7.5, 45, 0, '#1565c0');
    sign(['EXIT  >>', 'LEAVE AIRPORT'], 7, 1.6, 0, 7.5, 62, 0, '#2e7d32');

    // ----- exit gate & zone -----
    const E = ctx.B('exitgate');
    E.rect(-10.7, 0, 73.4, -10, 6, 75, 0xeceff1); E.rect(10, 0, 73.4, 10.7, 6, 75, 0xeceff1);
    E.rect(-10.7, 5.6, 73.4, 10.7, 6.4, 75, 0x2e7d32);
    E.rect(-10.7, 0, 73.4, -10, 0.8, 75, 0xd32f2f); E.rect(10, 0, 73.4, 10.7, 0.8, 75, 0xd32f2f);
    for (let i = 0; i < 6; i++) E.rect(-9.9 + i * 0.5, 4.6, 74.0, -9.4 + i * 0.5, 4.7, 74.2, i % 2 ? 0xffffff : 0xd32f2f);
    sign(['AIRPORT EXIT', 'ESCAPE HERE!'], 14, 2.4, 0, 5.0, 74.1, 0, '#00c853', '#ffffff');
    // chevrons guiding smugglers down the centre lane
    for (let z = 38; z < 65; z += 4.5) {
      E.e.box(-0.65, 0.03, z + 0.25, 0.32, 0.02, 1.9, 0x69f0ae, Math.PI / 4);
      E.e.box(0.65, 0.03, z + 0.25, 0.32, 0.02, 1.9, 0x69f0ae, -Math.PI / 4);
    }
    const zoneW = C.EXIT.x2 - C.EXIT.x1, zoneD = C.EXIT.z2 - C.EXIT.z1;
    const zoneMat = new THREE.MeshBasicMaterial({ color: 0x00e676, transparent: true, opacity: 0.35, depthWrite: false });
    const zone = new THREE.Mesh(new THREE.PlaneGeometry(zoneW, zoneD), zoneMat);
    zone.rotation.x = -Math.PI / 2; zone.position.set(0, 0.07, (C.EXIT.z1 + C.EXIT.z2) / 2); scene.add(zone);
    const beamMat = new THREE.MeshBasicMaterial({ color: 0x69f0ae, transparent: true, opacity: 0.22, depthWrite: false });
    [[-10, 66], [10, 66], [-10, 73.4], [10, 73.4]].forEach(function (p) {
      const m = new THREE.Mesh(new THREE.BoxGeometry(0.5, 16, 0.5), beamMat); m.position.set(p[0], 8, p[1]); scene.add(m);
    });
    ctx.anim.push(function (t) { zoneMat.opacity = 0.28 + 0.14 * Math.sin(t * 3.2); beamMat.opacity = 0.18 + 0.1 * Math.sin(t * 3.2 + 1); });

    // ----- planes parked at the gates, with jet bridges -----
    [-21, 7, 35].forEach(function (px, i) {
      const cz = -66, white = 0xfafafa, tail = [0xe53935, 0x1e88e5, 0xfb8c00][i];
      AP.cyl(px, 4.4, cz, 2.2, 2.2, 30, 10, white, 'z');
      AP.cyl(px, 4.4, cz + 15 + 1.8, 0, 2.2, 3.6, 10, 0xeceff1, 'z');
      AP.cyl(px, 4.7, cz - 15 - 2.5, 2.2, 0.6, 5, 10, white, 'z');
      AP.box(px + 6.5, 3.3, cz + 1.5, 13.5, 0.35, 4.6, 0xdfe6ea, 0.38);
      AP.box(px - 6.5, 3.3, cz + 1.5, 13.5, 0.35, 4.6, 0xdfe6ea, -0.38);
      [-6.5, 6.5].forEach(function (dx) { AP.cyl(px + dx, 2.4, cz + 2.5, 0.8, 0.8, 3.2, 8, 0x90a4ae, 'z'); });
      AP.box(px, 7.0, cz - 16.5, 0.4, 4.8, 4.2, tail, 0);
      AP.box(px, 5.0, cz - 17, 9, 0.3, 2.6, white, 0);
      AP.rect(px + 2.18, 4.6, cz - 11, px + 2.28, 5.2, cz + 12, 0x37474f);
      AP.rect(px - 2.28, 4.6, cz - 11, px - 2.18, 5.2, cz + 12, 0x37474f);
      AP.rect(px - 1.0, 5.0, cz + 18.3, px + 1.0, 5.6, cz + 19.4, 0x37474f);
      AP.rect(px - 1.5, 2.4, -46, px + 1.5, 5.0, -31, 0xb0bec5);   // jet bridge
      AP.rect(px - 1.5, 4.9, -46, px + 1.5, 5.0, -31, 0x607d8b);
      AP.rect(px - 0.3, 0, -40, px + 0.3, 2.4, -39.4, 0x607d8b);
    });
    // baggage trolleys on the apron
    for (let i = 0; i < 6; i++) {
      const x = -50 + i * 20 + rnd() * 5, z = -38 - rnd() * 6;
      AP.rect(x, 0.3, z, x + 5, 0.8, z + 1.6, 0x546e7a); AP.rect(x + 0.2, 0.8, z + 0.1, x + 1.6, 1.5, z + 1.5, 0xf57c00);
      AP.rect(x + 1.9, 0.8, z + 0.1, x + 3.3, 1.5, z + 1.5, 0x1976d2);
    }

    // ----- scenery: trees outside the fence, hills, clouds -----
    for (let i = 0; i < 46; i++) {
      const side = rnd() < 0.5 ? -1 : 1, x = side * (68 + rnd() * 40), z = -30 + rnd() * 120, h = 3 + rnd() * 3;
      SKY.cyl(x, 0.8, z, 0.25, 0.3, 1.6, 5, 0x6d4c41);
      SKY.cyl(x, 1.6 + h / 2, z, 0, 1.7 + rnd(), h, 6, rnd() < 0.5 ? 0x2e7d32 : 0x43a047);
    }
    for (let i = 0; i < 16; i++) {
      const a = (i / 16) * Math.PI * 2 + rnd() * 0.3, r = 210 + rnd() * 40, h = 30 + rnd() * 50;
      SKY.cyl(Math.cos(a) * r, h / 2, 20 + Math.sin(a) * r, 0, 45 + rnd() * 30, h, 6, rnd() < 0.5 ? 0x7aa874 : 0x8ea3a0);
    }
    for (let i = 0; i < 14; i++) {
      const cx = (rnd() - 0.5) * 360, cz = (rnd() - 0.5) * 300, cy = 70 + rnd() * 30;
      SKY.e.box(cx, cy, cz, 22 + rnd() * 14, 4, 10 + rnd() * 6, 0xffffff);
      SKY.e.box(cx + 4, cy + 3, cz, 12, 4, 8, 0xffffff);
    }

    // ----- moving traffic on the access road (deterministic from the shared clock) -----
    const bg = new THREE.BoxGeometry(1, 1, 1), tmat = {};
    function mat(hex) { return tmat[hex] || (tmat[hex] = new THREE.MeshLambertMaterial({ color: hex })); }
    const veh = C.TRAFFIC.map(function (v) {
      const g = new THREE.Group();
      function part(sx, sy, sz, x, y, z, hex) { const m = new THREE.Mesh(bg, mat(hex)); m.scale.set(sx, sy, sz); m.position.set(x, y, z); g.add(m); }
      part(v.len, v.h * 0.55, v.wid, 0, 0.3 + v.h * 0.27, 0, v.color);
      if (v.bus) part(v.len - 0.4, 0.9, v.wid + 0.04, 0, 2.2, 0, 0x37474f);
      else part(v.len * 0.5, 0.6, v.wid - 0.15, -0.2, v.h * 0.55 + 0.55, 0, 0x37474f);
      [-v.len * 0.33, v.len * 0.33].forEach(function (x) { part(0.8, 0.8, v.wid + 0.1, x, 0.4, 0, 0x212121); });
      g.position.set(0, 0, v.z); scene.add(g);
      return g;
    });
    ctx.anim.push(function (t) {
      for (let i = 0; i < veh.length; i++) {
        const v = C.TRAFFIC[i];
        veh[i].position.x = C.trafficPos(v, t);
        veh[i].rotation.y = v.dir > 0 ? 0 : Math.PI;
      }
    });
  };
})();
