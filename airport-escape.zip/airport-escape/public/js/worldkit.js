/* AIRPORT ESCAPE - world toolkit: merged low-poly geometry builder, canvas signs, build orchestration.
 * Everything static is merged into a handful of meshes so mobile GPUs only see a few dozen draw calls. */
(function () {
  'use strict';
  const FACES = [
    { n: [1, 0, 0], v: [[1, -1, -1], [1, 1, -1], [1, 1, 1], [1, -1, 1]] },
    { n: [-1, 0, 0], v: [[-1, -1, 1], [-1, 1, 1], [-1, 1, -1], [-1, -1, -1]] },
    { n: [0, 1, 0], v: [[-1, 1, -1], [-1, 1, 1], [1, 1, 1], [1, 1, -1]] },
    { n: [0, -1, 0], v: [[-1, -1, 1], [-1, -1, -1], [1, -1, -1], [1, -1, 1]] },
    { n: [0, 0, 1], v: [[-1, -1, 1], [1, -1, 1], [1, 1, 1], [-1, 1, 1]] },
    { n: [0, 0, -1], v: [[1, -1, -1], [-1, -1, -1], [-1, 1, -1], [1, 1, -1]] }
  ];
  const QUAD = [0, 1, 2, 0, 2, 3];
  const colCache = {};
  function rgb(hex) {
    let c = colCache[hex];
    if (!c) { const k = new THREE.Color(hex); c = colCache[hex] = [k.r, k.g, k.b]; }
    return c;
  }

  function Builder() { this.p = []; this.n = []; this.c = []; }
  /* axis-aligned box (optionally rotated around Y). cx,cy,cz = centre, sx,sy,sz = full size */
  Builder.prototype.box = function (cx, cy, cz, sx, sy, sz, hex, ry) {
    const col = rgb(hex), hx = sx / 2, hy = sy / 2, hz = sz / 2;
    const cs = ry ? Math.cos(ry) : 1, sn = ry ? Math.sin(ry) : 0;
    for (let f = 0; f < 6; f++) {
      const F = FACES[f];
      const nx = F.n[0] * cs + F.n[2] * sn, nz = -F.n[0] * sn + F.n[2] * cs, ny = F.n[1];
      for (let i = 0; i < 6; i++) {
        const q = F.v[QUAD[i]], lx = q[0] * hx, ly = q[1] * hy, lz = q[2] * hz;
        this.p.push(cx + lx * cs + lz * sn, cy + ly, cz - lx * sn + lz * cs);
        this.n.push(nx, ny, nz); this.c.push(col[0], col[1], col[2]);
      }
    }
  };
  /* box given by min/max corners (handy with collider rectangles) */
  Builder.prototype.rect = function (x1, y1, z1, x2, y2, z2, hex) {
    this.box((x1 + x2) / 2, (y1 + y2) / 2, (z1 + z2) / 2, x2 - x1, y2 - y1, z2 - z1, hex);
  };
  Builder.prototype.tri = function (a, b, c, col) {
    const ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2], vx = c[0] - a[0], vy = c[1] - a[1], vz = c[2] - a[2];
    let nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
    const l = Math.hypot(nx, ny, nz); if (l < 1e-9) return;
    nx /= l; ny /= l; nz /= l;
    const P = [a, b, c];
    for (let i = 0; i < 3; i++) { this.p.push(P[i][0], P[i][1], P[i][2]); this.n.push(nx, ny, nz); this.c.push(col[0], col[1], col[2]); }
  };
  /* low-poly cylinder / cone. axis: 'y' (default), 'z' or 'x'. rt/rb = top/bottom radius */
  Builder.prototype.cyl = function (cx, cy, cz, rt, rb, h, seg, hex, axis) {
    const col = rgb(hex), self = this, hh = h / 2;
    function T(x, y, z) {
      if (axis === 'z') return [cx + x, cy - z, cz + y];
      if (axis === 'x') return [cx + y, cy - x, cz + z];
      return [cx + x, cy + y, cz + z];
    }
    for (let i = 0; i < seg; i++) {
      const a0 = (i / seg) * Math.PI * 2, a1 = ((i + 1) / seg) * Math.PI * 2;
      const b0 = T(Math.cos(a0) * rb, -hh, Math.sin(a0) * rb), b1 = T(Math.cos(a1) * rb, -hh, Math.sin(a1) * rb);
      const t0 = T(Math.cos(a0) * rt, hh, Math.sin(a0) * rt), t1 = T(Math.cos(a1) * rt, hh, Math.sin(a1) * rt);
      self.tri(b0, t0, t1, col); self.tri(b0, t1, b1, col);
      self.tri(T(0, hh, 0), t1, t0, col); self.tri(T(0, -hh, 0), b0, b1, col);
    }
  };
  Builder.prototype.build = function (mat) {
    if (!this.p.length) return null;
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(this.p), 3));
    g.setAttribute('normal', new THREE.BufferAttribute(new Float32Array(this.n), 3));
    g.setAttribute('color', new THREE.BufferAttribute(new Float32Array(this.c), 3));
    g.computeBoundingSphere();
    return new THREE.Mesh(g, mat);
  };

  const World = {};
  window.World = World;
  World.Builder = Builder;
  World.rgb = rgb;

  World.build = function (scene) {
    // ----- atmosphere & light -----
    const sky = 0xa9d6ff;
    scene.background = new THREE.Color(sky);
    scene.fog = new THREE.Fog(sky, 70, 200);
    scene.add(new THREE.HemisphereLight(0xeaf4ff, 0x9a917f, 0.95));
    const sun = new THREE.DirectionalLight(0xfff1d6, 0.75);
    sun.position.set(-40, 80, 30); scene.add(sun);

    const mats = {
      o: new THREE.MeshLambertMaterial({ vertexColors: true }),
      g: new THREE.MeshLambertMaterial({ vertexColors: true, transparent: true, opacity: 0.3, depthWrite: false }),
      e: new THREE.MeshBasicMaterial({ vertexColors: true })
    };
    const chunks = {};
    // B('hall') -> opaque lit builder; B('hall').g = glass builder; B('hall').e = unlit/emissive builder
    function B(name) {
      if (!chunks[name]) {
        const c = { o: new Builder(), g: new Builder(), e: new Builder() };
        c.o.g = c.g; c.o.e = c.e; chunks[name] = c;
      }
      return chunks[name].o;
    }

    // ----- canvas text signs (double sided, unlit) -----
    const texCache = {};
    function textTexture(lines, w, h, bg, fg) {
      const key = lines.join('|') + bg + fg + w + h;
      if (texCache[key]) return texCache[key];
      const cv = document.createElement('canvas');
      cv.width = Math.min(512, Math.round(w * 64)); cv.height = Math.max(32, Math.round(cv.width * h / w));
      const x = cv.getContext('2d');
      x.fillStyle = bg; x.fillRect(0, 0, cv.width, cv.height);
      x.strokeStyle = 'rgba(255,255,255,.35)'; x.lineWidth = 4; x.strokeRect(2, 2, cv.width - 4, cv.height - 4);
      x.fillStyle = fg; x.textAlign = 'center'; x.textBaseline = 'middle';
      const lh = cv.height / lines.length;
      lines.forEach(function (t, i) {
        let fs = lh * 0.7; x.font = '800 ' + fs + 'px Arial, sans-serif';
        while (x.measureText(t).width > cv.width * 0.92 && fs > 8) { fs -= 2; x.font = '800 ' + fs + 'px Arial, sans-serif'; }
        x.fillText(t, cv.width / 2, lh * (i + 0.52));
      });
      const tex = new THREE.CanvasTexture(cv);
      tex.anisotropy = 2;
      return (texCache[key] = tex);
    }
    const signMats = {};
    function sign(lines, w, h, x, y, z, ry, bg, fg) {
      if (typeof lines === 'string') lines = [lines];
      const tex = textTexture(lines, w, h, bg || '#0d47a1', fg || '#ffffff');
      const mk = tex.uuid;
      const m = signMats[mk] || (signMats[mk] = new THREE.MeshBasicMaterial({ map: tex, side: THREE.DoubleSide }));
      const mesh = new THREE.Mesh(new THREE.PlaneGeometry(w, h), m);
      mesh.position.set(x, y, z); mesh.rotation.y = ry || 0;
      scene.add(mesh);
      return mesh;
    }

    const ctx = { scene: scene, B: B, sign: sign, mats: mats, C: SHARED, anim: [] };
    World.ground(ctx);
    World.shell(ctx);
    World.interior(ctx);
    World.exterior(ctx);

    Object.keys(chunks).forEach(function (k) {
      ['o', 'g', 'e'].forEach(function (t) {
        const mesh = chunks[k][t].build(mats[t]);
        if (mesh) { mesh.name = 'static_' + k + '_' + t; scene.add(mesh); }
      });
    });
    return ctx;
  };

  /* ------------ ground, floors and the building shell ------------ */
  World.ground = function (ctx) {
    const G = ctx.B('ground'), C = ctx.C;
    G.rect(-400, -0.6, -400, 400, -0.02, 400, 0x86b94a);                  // grass
    G.rect(-130, -0.02, -140, 130, 0.0, -31, 0x6f7a85);                   // apron tarmac behind the terminal
    G.rect(-61, -0.02, -35, 61, 0.0, -31, 0x6f7a85);
    G.rect(-61, -0.02, 30, 61, 0.03, 36, 0xcfd3d8);                       // sidewalk / drop-off kerb
    G.rect(-130, -0.02, 36, 130, 0.0, 44, 0x3c4149);                      // access road
    G.rect(-61, -0.02, 44, 61, 0.0, 75, 0x4a4f57);                        // parking lot
    G.rect(-61, -0.02, -35, -51, 0.0, 44, 0x9aa29a);                      // paths beside terminal
    G.rect(51, -0.02, -35, 61, 0.0, 44, 0x9aa29a);
    for (let x = -120; x < 120; x += 8) G.rect(x, 0.001, 39.9, x + 4, 0.012, 40.1, 0xf4f4f4);   // dashed road line
    // parking bay lines and aisles
    [46, 49, 55.5, 58.5, 65, 68].forEach(function (zc) {
      for (let x = -55; x <= 55; x += 6.5) { if (Math.abs(x) < 13) continue; G.rect(x, 0.001, zc - 1.1, x + 0.12, 0.012, zc + 1.1, 0xe8e8e8); }
    });
    // crosswalk in front of the doors
    for (let x = -5; x <= 5; x += 1.4) G.rect(x, 0.001, 36.4, x + 0.7, 0.012, 43.6, 0xf4f4f4);
    // terminal floor zones (thin coloured slabs over a tiled floor)
    const tex = (function () {
      const cv = document.createElement('canvas'); cv.width = cv.height = 64;
      const x = cv.getContext('2d'); x.fillStyle = '#eceff3'; x.fillRect(0, 0, 64, 64);
      x.fillStyle = '#dfe4ea'; x.fillRect(0, 0, 32, 32); x.fillRect(32, 32, 32, 32);
      const t = new THREE.CanvasTexture(cv); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(26, 16); return t;
    })();
    const floor = new THREE.Mesh(new THREE.PlaneGeometry(102, 62), new THREE.MeshLambertMaterial({ map: tex }));
    floor.rotation.x = -Math.PI / 2; floor.position.set(0, 0.0, 0); ctx.scene.add(floor);
    const Z = ctx.B('floor');
    Z.rect(-42, 0.01, -30, 42, 0.03, -20, 0x5c6bc0);                      // gate carpet
    Z.rect(-50, 0.01, -4, 50, 0.03, 2.6, 0x9fa8b3);                       // security floor strip
    C.LANES.forEach(function (gx) { Z.rect(gx - 2.5, 0.012, -4, gx + 2.5, 0.035, 2.6, 0x37474f); });
    Z.rect(-50, 0.01, 14, 50, 0.03, 19, 0xffe082);                        // check-in aisle
    Z.rect(-6, 0.01, 22, 6, 0.03, 31, 0xb0bec5);                          // path to the main doors
  };

  World.shell = function (ctx) {
    const S = ctx.B('shell'), C = ctx.C;
    C.COLLIDERS.forEach(function (c) {
      const w = c.x2 - c.x1, d = c.z2 - c.z1;
      if (c.kind === 'wall') {
        S.rect(c.x1, 0, c.z1, c.x2, c.h, c.z2, 0xf3efe6);
        S.rect(c.x1 - 0.05, 0, c.z1, c.x2 + 0.05, 1.2, c.z2, 0x5c6bc0);
        for (let z = -26; z <= 26; z += 10) S.rect(c.x1 - 0.5, 0, z - 0.4, c.x2 + 0.5, c.h, z + 0.4, 0xe0dccf);
      } else if (c.kind === 'glass') {
        ctx.B('shell').g.rect(c.x1, 0.5, c.z1, c.x2, c.h, c.z2, 0x8fd3ff);
        S.rect(c.x1, 0, c.z1, c.x2, 0.5, c.z2, 0xf3efe6);
        for (let x = c.x1; x <= c.x2 + 0.01; x += 5) S.rect(x - 0.15, 0, c.z1 - 0.1, x + 0.15, c.h, c.z2 + 0.1, 0xb0bec5);
        S.rect(c.x1, c.h - 0.3, c.z1 - 0.1, c.x2, c.h, c.z2 + 0.1, 0xb0bec5);
      } else if (c.kind === 'fence') {
        const g = ctx.B('ground');
        g.rect(c.x1, 0, c.z1, c.x2, 2, c.z2, 0x9eb0bd);
      }
    });
    // main door frame + door canopy
    S.rect(-6.4, 0, 30, -6, 5, 31, 0x37474f); S.rect(6, 0, 30, 6.4, 5, 31, 0x37474f); S.rect(-6.4, 5, 30, 6.4, 5.5, 31, 0x37474f);
    // roof (unlit, bright) with skylights, trusses and light strips
    const R = ctx.B('roof').e;
    R.rect(-51, 10, -31, 51, 10.6, 31, 0xe6ebf2);
    for (let z = -26; z <= 26; z += 10) R.rect(-50, 9.5, z - 0.3, 50, 10, z + 0.3, 0x8d99a8);
    for (let x = -40; x <= 40; x += 20) for (let z = -24; z <= 24; z += 8) R.rect(x - 4, 9.4, z - 0.25, x + 4, 9.5, z + 0.25, 0xfffbe6);
    R.rect(-51, 10.6, -31, 51, 11.2, -30, 0xcfd8e3); R.rect(-51, 10.6, 30, 51, 11.2, 31, 0xcfd8e3);
    // front canopy over the drop-off
    const E = ctx.B('ext');
    E.rect(-45, 7.2, 31, 45, 7.7, 37, 0xf5f5f5); E.rect(-45, 7.7, 31, 45, 7.9, 37, 0x1e88e5);
  };
})();
