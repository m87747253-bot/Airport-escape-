/* AIRPORT ESCAPE - Socket.IO client wrapper with server clock synchronisation. */
(function () {
  'use strict';
  let socket = null, offset = 0, bestRtt = Infinity;
  const pending = [];                       // handlers registered before connect()

  function sync(n) {
    if (!socket) return;
    let left = n || 6;
    (function one() {
      const t0 = Date.now();
      socket.emit('ping', function (srv) {
        const t1 = Date.now(), rtt = t1 - t0;
        if (rtt < bestRtt || left === (n || 6)) { bestRtt = rtt; offset = srv + rtt / 2 - t1; }
        if (--left > 0) setTimeout(one, 120);
      });
    })();
  }

  const Net = {
    connected: false,
    id: null,
    now: function () { return Date.now() + offset; },
    rtt: function () { return bestRtt === Infinity ? 0 : bestRtt; },
    on: function (evt, fn) { if (socket) socket.on(evt, fn); else pending.push([evt, fn]); },
    emit: function (evt, a, b) { if (socket && socket.connected) socket.emit(evt, a, b); },
    connect: function () {
      if (socket) return;
      socket = io({ transports: ['websocket', 'polling'] });
      pending.forEach(function (p) { socket.on(p[0], p[1]); });
      socket.on('connect', function () { Net.connected = true; bestRtt = Infinity; sync(8); });
      socket.on('disconnect', function () { Net.connected = false; Net.id = null; });
      setInterval(function () { if (socket.connected) { bestRtt = Infinity; sync(4); } }, 15000);
    },
    join: function (name, room) {
      return new Promise(function (resolve) {
        if (!socket) return resolve({ ok: false, err: 'Not connected' });
        const go = function () {
          socket.emit('join', { name: name, room: room }, function (res) {
            if (res && res.ok) Net.id = res.id;
            resolve(res || { ok: false, err: 'No response' });
          });
        };
        if (socket.connected) go(); else socket.once('connect', go);
        setTimeout(function () { resolve({ ok: false, err: 'Could not reach the server' }); }, 8000);
      });
    }
  };
  window.Net = Net;
})();
