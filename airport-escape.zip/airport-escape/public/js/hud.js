/* AIRPORT ESCAPE - DOM overlays: menu, lobby, HUD, results, mini-map. */
(function () {
  'use strict';
  const $ = function (id) { return document.getElementById(id); };
  const C = SHARED;
  const HUD = {};
  let toastTimer = 0;

  HUD.show = function (name) {          // 'menu' | 'lobby' | 'hud' | 'results'
    ['menu', 'lobby', 'hud', 'results'].forEach(function (n) { $(n).classList.toggle('hidden', n !== name); });
    document.body.classList.toggle('playing', name === 'hud');
  };
  HUD.toast = function (msg) {
    const t = $('toast'); t.textContent = msg; t.classList.add('show');
    clearTimeout(toastTimer); toastTimer = setTimeout(function () { t.classList.remove('show'); }, 2600);
  };
  HUD.banner = function (html) { $('banner').innerHTML = html || ''; };
  HUD.objective = function (txt) { $('objective').textContent = txt; };
  HUD.feed = function (txt, color) {
    const f = $('feed'), d = document.createElement('div'); d.textContent = txt; if (color) d.style.color = color;
    f.appendChild(d); while (f.children.length > 4) f.removeChild(f.firstChild);
    setTimeout(function () { if (d.parentNode) d.parentNode.removeChild(d); }, 6000);
  };
  HUD.clearFeed = function () { $('feed').innerHTML = ''; };

  HUD.renderLobby = function (info, myId) {
    $('lobbyCode').textContent = info.code;
    ['police', 'smuggler'].forEach(function (team) {
      const ul = $(team === 'police' ? 'listPolice' : 'listSmuggler'); ul.innerHTML = '';
      let n = 0;
      info.players.forEach(function (p) {
        if (p.team !== team) return; n++;
        const li = document.createElement('li'); if (p.id === myId) li.className = 'me';
        li.textContent = p.name; if (p.id === info.hostId) { const s = document.createElement('span'); s.textContent = '★ host'; li.appendChild(s); }
        ul.appendChild(li);
      });
      $(team === 'police' ? 'cntPolice' : 'cntSmuggler').textContent = n;
    });
    const host = info.hostId === myId, btn = $('btnStart');
    btn.disabled = !host; btn.textContent = host ? 'START MATCH' : 'WAITING FOR HOST...';
    $('lobbyMsg').textContent = host ? 'Need at least 1 Police and 1 Smuggler. Share code ' + info.code + ' with friends!' : 'The host will start the match.';
  };

  HUD.setTeam = function (team) {
    const b = $('teamBadge'); b.className = team; b.textContent = team === 'police' ? '👮 POLICE' : '👜 SMUGGLER';
  };
  HUD.setTime = function (sec) {
    sec = Math.max(0, Math.ceil(sec)); $('timer').textContent = Math.floor(sec / 60) + ':' + ('0' + (sec % 60)).slice(-2);
  };
  HUD.setRemain = function (n) { $('remain').textContent = '👜 ' + n + ' free'; };
  HUD.stamina = function (frac, low) { const s = $('stamina'); s.style.width = Math.round(frac * 100) + '%'; s.classList.toggle('low', !!low); };

  HUD.renderResults = function (d, myTeam, myId) {
    const win = d.winner === myTeam;
    const t = $('resTitle'); t.textContent = (d.winner === 'police' ? 'POLICE WIN!' : 'SMUGGLERS ESCAPED!');
    t.style.color = d.winner === 'police' ? '#64b5f6' : '#ffa726';
    $('resReason').textContent = (win ? 'VICTORY — ' : 'DEFEAT — ') + d.reason;
    const rows = ['<tr><th>Player</th><th>Team</th><th>Result</th></tr>'];
    d.results.slice().sort(function (a, b) { return a.team < b.team ? 1 : -1; }).forEach(function (p) {
      let res;
      if (p.team === 'police') res = p.caps + ' capture' + (p.caps === 1 ? '' : 's');
      else res = p.escaped ? '<span class="good">ESCAPED</span>' : p.alive ? 'Still free' : '<span class="bad">CAUGHT</span>';
      rows.push('<tr><td>' + esc(p.name) + (p.id === myId ? ' (you)' : '') + '</td><td class="' + (p.team === 'police' ? 'pol' : 'smu') + '">' + p.team + '</td><td>' + res + '</td></tr>');
    });
    $('resTable').innerHTML = rows.join('');
    $('resMsg').textContent = '';
  };
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  /* ---- mini-map ---- */
  const mm = $('minimap'), mx = mm.getContext('2d');
  const X0 = -62, Z0 = -36, SX = mm.width / 124, SZ = mm.height / 111;
  const staticMap = document.createElement('canvas'); staticMap.width = mm.width; staticMap.height = mm.height;
  (function drawStatic() {
    const g = staticMap.getContext('2d');
    g.fillStyle = '#4f7a3a'; g.fillRect(0, 0, mm.width, mm.height);
    g.fillStyle = '#3c4149'; g.fillRect(0, (36 - Z0) * SZ, mm.width, 8 * SZ);
    g.fillStyle = '#4a4f57'; g.fillRect(0, (44 - Z0) * SZ, mm.width, 31 * SZ);
    g.fillStyle = '#e8ecf2'; g.fillRect((-50 - X0) * SX, (-30 - Z0) * SZ, 100 * SX, 60 * SZ);
    C.COLLIDERS.forEach(function (c) {
      let col = '#37474f';
      if (c.kind === 'car') col = '#78909c'; else if (c.kind === 'shop') col = '#ffb74d';
      else if (c.kind === 'counter' || c.kind === 'desk') col = '#5c6bc0'; else if (c.kind === 'bench' || c.kind === 'table') col = '#90a4ae';
      else if (c.kind === 'fence') col = '#222';
      g.fillStyle = col; g.fillRect((c.x1 - X0) * SX, (c.z1 - Z0) * SZ, Math.max(1, (c.x2 - c.x1) * SX), Math.max(1, (c.z2 - c.z1) * SZ));
    });
    g.fillStyle = '#00e676'; const e = C.EXIT; g.fillRect((e.x1 - X0) * SX, (e.z1 - Z0) * SZ, (e.x2 - e.x1) * SX, (e.z2 - e.z1) * SZ);
  })();
  HUD.minimap = function (list, t) {
    mx.drawImage(staticMap, 0, 0);
    const e = C.EXIT; mx.strokeStyle = 'rgba(0,255,130,' + (0.5 + 0.5 * Math.sin(t * 4)) + ')'; mx.lineWidth = 2;
    mx.strokeRect((e.x1 - X0) * SX, (e.z1 - Z0) * SZ, (e.x2 - e.x1) * SX, (e.z2 - e.z1) * SZ);
    list.forEach(function (p) {
      const x = (p.x - X0) * SX, y = (p.z - Z0) * SZ;
      mx.beginPath(); mx.arc(x, y, p.me ? 5 : 3.6, 0, 6.283);
      mx.fillStyle = !p.alive ? '#9e9e9e' : p.team === 'police' ? '#2979ff' : '#ff9100'; mx.fill();
      if (p.me) { mx.lineWidth = 2; mx.strokeStyle = '#fff'; mx.stroke(); }
    });
  };
  window.HUD = HUD;
})();
