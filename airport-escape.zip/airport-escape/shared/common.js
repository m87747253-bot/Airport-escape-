/* AIRPORT ESCAPE - shared constants, map data and deterministic NPC simulation.
 * Loaded by BOTH the Node server (require) and the browser (<script>).
 * World axes: x = east/west, z = north(-)/south(+), y = up. Units are metres.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.SHARED = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  const C = {};

  /* ---------------- gameplay constants ---------------- */
  C.WALK = 3.6;
  C.RUN = 7.0;
  C.POLICE_BONUS = 1.03;          // police run slightly faster
  C.STAMINA = { max: 100, drain: 20, regen: 14, minStart: 18 };
  C.CATCH_RANGE = 3.0;            // client-side range
  C.CATCH_RANGE_SERVER = 3.6;     // server allows a little lag slack
  C.COUNTDOWN_MS = 4000;
  C.POLICE_FREEZE_MS = 5000;      // smugglers get a head start
  C.ROUND_MS = 180000;
  C.MAX_PLAYERS = 16;
  C.MAX_PER_TEAM = 10;
  C.PLAYER_RADIUS = 0.42;
  C.BOUNDS = { x1: -60.5, z1: -34.5, x2: 60.5, z2: 73.5 };
  C.EXIT = { x1: -10, z1: 66, x2: 10, z2: 73.5 };

  /* ---------------- helpers ---------------- */
  C.mulberry32 = function (a) {
    return function () {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  };
  C.inRect = function (x, z, r) { return x >= r.x1 && x <= r.x2 && z >= r.z1 && z <= r.z2; };

  /* ---------------- static map (colliders double as render data) ---------------- */
  const COL = [];
  function box(kind, x1, z1, x2, z2, h, extra) {
    COL.push(Object.assign({ kind: kind, x1: x1, z1: z1, x2: x2, z2: z2, h: h }, extra || {}));
  }
  // terminal shell
  box('glass', -51, -31, 51, -30, 10);                 // north glass wall facing the apron
  box('wall', -51, -30, -50, 31, 10);                  // west wall
  box('wall', 50, -30, 51, 31, 10);                    // east wall
  box('glass', -50, 30, -6, 31, 10);                   // front glass, west of main doors
  box('glass', 6, 30, 50, 31, 10);                     // front glass, east of main doors
  // security wall with 4 lanes
  C.LANES = [-30, -10, 10, 30];
  const segs = [[-50, -32.5], [-27.5, -12.5], [-7.5, 7.5], [12.5, 27.5], [32.5, 50]];
  segs.forEach(function (s) { box('secwall', s[0], -4, s[1], -3, 4.5); });
  C.LANES.forEach(function (gx) {
    box('xray', gx - 5, -3, gx - 2.5, -0.8, 1.1);
    box('xray', gx + 2.5, -3, gx + 5, -0.8, 1.1);
  });
  // check-in counters (two rows facing the aisle between them)
  C.COUNTER_X = [-40, -24, -8, 8, 24, 40];
  C.COUNTER_X.forEach(function (cx) {
    box('counter', cx - 4.5, 12, cx + 4.5, 14, 1.2, { cx: cx, row: 0 });
    box('counter', cx - 4.5, 19, cx + 4.5, 21, 1.2, { cx: cx, row: 1 });
  });
  // gates
  C.GATE_X = [-35, -21, -7, 7, 21, 35];
  C.GATE_X.forEach(function (gx, i) {
    box('desk', gx - 3, -29.5, gx + 3, -27.5, 1.2, { gate: i });
    box('bench', gx - 5, -25, gx + 5, -24, 0.5);
    box('bench', gx - 5, -22.5, gx + 5, -21.5, 0.5);
  });
  // shops & restaurants (solid blocks along the side walls)
  C.SHOPS = [
    { name: 'BURGER HUB', x1: -49.5, z1: -26, x2: -43, z2: -21, side: -1, color: 0xff7043 },
    { name: 'DUTY FREE', x1: -49.5, z1: -19.5, x2: -43, z2: -14.5, side: -1, color: 0x7e57c2 },
    { name: 'COFFEE', x1: -49.5, z1: -12.5, x2: -43, z2: -7.5, side: -1, color: 0x8d6e63 },
    { name: 'SUSHI BAR', x1: 43, z1: -26, x2: 49.5, z2: -21, side: 1, color: 0xe53935 },
    { name: 'BOOKS & GIFTS', x1: 43, z1: -19.5, x2: 49.5, z2: -14.5, side: 1, color: 0x26a69a },
    { name: 'TECH STORE', x1: 43, z1: -12.5, x2: 49.5, z2: -7.5, side: 1, color: 0x1e88e5 }
  ];
  C.SHOPS.forEach(function (s) { box('shop', s.x1, s.z1, s.x2, s.z2, 4.2, { shop: s }); });
  // food court
  C.TABLE_X = [-34, -26, 26, 34];
  C.TABLE_X.forEach(function (tx) { box('table', tx - 0.8, -11.8, tx + 0.8, -10.2, 0.8); });
  box('kiosk', -1.5, -12, 1.5, -10, 2.6);
  // hall benches
  C.HALL_BENCH_X = [-40, -30, 30, 40];
  C.HALL_BENCH_X.forEach(function (bx) { box('bench', bx - 3, 28, bx + 3, 29.2, 0.5); });
  // front pillars / planters
  [-40, -20, 20, 40].forEach(function (px) { box('pillar', px - 0.5, 34, px + 0.5, 35, 7); });
  [-45, -30, 30, 45].forEach(function (px) { box('planter', px - 0.9, 32.6, px + 0.9, 33.8, 1.2); });
  // parking lot cars (deterministic layout)
  (function () {
    const r = C.mulberry32(1234);
    const rows = [46, 49, 55.5, 58.5, 65, 68];
    C.CAR_COLORS = [0xe53935, 0x1e88e5, 0xfdd835, 0x43a047, 0xffffff, 0x8e24aa, 0xfb8c00, 0x455a64, 0x00acc1];
    rows.forEach(function (zc) {
      [[-55, -15], [15, 55]].forEach(function (span) {
        for (let x = span[0] + 2.3; x <= span[1]; x += 6.5) {
          if (r() < 0.72) {
            box('car', x - 2.3, zc - 1, x + 2.3, zc + 1, 1.5, { color: C.CAR_COLORS[(r() * C.CAR_COLORS.length) | 0] });
          }
        }
      });
    });
  })();
  // outer fence (gaps at the road and at the exit)
  box('fence', -62, -35, -61, 36, 2);
  box('fence', -62, 44, -61, 75, 2);
  box('fence', 61, -35, 62, 36, 2);
  box('fence', 61, 44, 62, 75, 2);
  box('fence', -62, -36, 62, -35, 2);
  box('fence', -62, 74, -10, 75, 2);
  box('fence', 10, 74, 62, 75, 2);
  C.COLLIDERS = COL;

  /* ---------------- moving traffic on the access road ---------------- */
  C.TRAFFIC = [];
  (function () {
    const r = C.mulberry32(777);
    const cols = [0xfdd835, 0xe53935, 0x1e88e5, 0xffffff, 0x43a047, 0xff7043];
    [[38.2, 1], [41.8, -1]].forEach(function (lane, li) {
      for (let i = 0; i < 4; i++) {
        const bus = (i === 0 && li === 0);
        C.TRAFFIC.push({
          z: lane[0], dir: lane[1], speed: 5 + r() * 3, off: (i / 4) * 150 + r() * 20,
          len: bus ? 9 : 4.4, wid: bus ? 2.6 : 1.9, h: bus ? 3.2 : 1.5, bus: bus,
          color: bus ? 0xfbc02d : cols[(r() * cols.length) | 0]
        });
      }
    });
  })();
  C.trafficPos = function (v, t) {
    let x = (v.off + v.dir * v.speed * t) % 150;
    if (x < 0) x += 150;
    return x - 75;
  };

  /* ---------------- spawns ---------------- */
  C.spawn = function (team, i, n) {
    const f = n <= 1 ? 0.5 : i / (n - 1);
    if (team === 'police') return [-26 + f * 52, 25.8, Math.PI];
    return [-32 + f * 64, -17, 0];
  };

  /* ---------------- NPC crowd (deterministic: position = f(seed, time)) ---------------- */
  const SKIN = [0xf1c6a0, 0xe0a97c, 0xc68642, 0x8d5524, 0x5a3825, 0xffdbac];
  const HAIR = [0x1b1b1b, 0x3b2417, 0x6b4423, 0xb58143, 0xd9c07c, 0x8a8a8a, 0xa83232];
  const SHIRT = [0xef5350, 0xec407a, 0xab47bc, 0x5c6bc0, 0x29b6f6, 0x26a69a, 0x9ccc65, 0xffee58, 0xffa726, 0xffffff, 0x90a4ae, 0x8d6e63];
  const PANTS = [0x2b3a55, 0x3d3d3d, 0x4a5d3a, 0x6b4f3a, 0x1f2a44, 0x7a7a7a, 0x30475e];
  C.SKIN = SKIN; C.HAIR = HAIR; C.SHIRT = SHIRT; C.PANTS = PANTS;
  const pick = function (r, a) { return a[(r() * a.length) | 0]; };

  function paxLook(r) {
    const a = { skin: pick(r, SKIN), hair: pick(r, HAIR), shirt: pick(r, SHIRT), pants: pick(r, PANTS),
      sleeveSkin: r() < 0.4, hat: null, acc: null, vest: null, scale: 0.9 + r() * 0.2 };
    const q = r();
    if (q < 0.35) a.acc = { kind: 'suit', color: pick(r, [0x37474f, 0xc62828, 0x1565c0, 0x6a1b9a, 0x2e7d32]) };
    else if (q < 0.55) a.acc = { kind: 'pack', color: pick(r, [0x455a64, 0xf57c00, 0x00838f, 0x5d4037]) };
    if (r() < 0.15) a.hat = pick(r, [0xe53935, 0x1e88e5, 0xfdd835, 0x212121, 0xffffff]);
    return a;
  }
  function staffLook(r, role) {
    const a = paxLook(r);
    a.acc = null; a.hat = null; a.sleeveSkin = false;
    if (role === 'agent') { a.shirt = 0x00897b; a.pants = 0x263238; a.vest = 0xffffff; }
    else if (role === 'guard') { a.shirt = 0x37474f; a.pants = 0x212121; a.hat = 0x263238; a.vest = 0xffd600; }
    else if (role === 'clerk') { a.shirt = 0xffffff; a.pants = 0x3e2723; a.vest = 0xd84315; }
    else { a.shirt = 0xfafafa; a.pants = 0x1a237e; a.vest = 0xffab00; a.hat = 0x1a237e; }   // check-in staff
    return a;
  }
  C.paxLook = paxLook;

  C.WALK_ZONES = [];
  (function () {
    const Z = C.WALK_ZONES;
    function triple(name, x1, x2, z1, z2, n) {
      const w = (x2 - x1) / 3;
      for (let i = 0; i < 3; i++) Z.push({ name: name + i, x1: x1 + i * w, x2: x1 + (i + 1) * w, z1: z1, z2: z2, n: n });
    }
    triple('air1', -42, 42, -20.2, -13.8, 7);
    triple('air2', -42, 42, -9.4, -5.6, 6);
    triple('hall1', -46, 46, 4, 10.2, 6);
    triple('hall2', -46, 46, 15.9, 17.1, 3);
    triple('hall3', -46, 46, 23.6, 27.6, 5);
    triple('curb', -45, 45, 31.8, 33.4, 3);
    Z.push({ name: 'park1', x1: -56, x2: -15, z1: 51, z2: 53.6, n: 4 });
    Z.push({ name: 'park2', x1: 15, x2: 56, z1: 51, z2: 53.6, n: 4 });
    Z.push({ name: 'park3', x1: -56, x2: -15, z1: 60.6, z2: 63.4, n: 4 });
    Z.push({ name: 'park4', x1: 15, x2: 56, z1: 60.6, z2: 63.4, n: 4 });
    Z.push({ name: 'mid', x1: -11, x2: 11, z1: 45, z2: 63, n: 4 });
    Z.push({ name: 'guards', x1: -44, x2: 44, z1: 1.4, z2: 2.8, n: 6, role: 'guard' });
  })();

  C.SEATS = [];
  (function () {
    const S = C.SEATS;
    C.GATE_X.forEach(function (gx) {
      [-24.5, -22].forEach(function (zb) {
        for (let k = -4; k <= 4; k += 2) S.push({ x: gx + k, z: zb, ry: Math.PI, h: 0.5 });
      });
    });
    C.TABLE_X.forEach(function (tx) {
      S.push({ x: tx - 1.3, z: -11, ry: Math.PI / 2, h: 0.5 }); S.push({ x: tx + 1.3, z: -11, ry: -Math.PI / 2, h: 0.5 });
      S.push({ x: tx, z: -12.6, ry: 0, h: 0.5 }); S.push({ x: tx, z: -9.4, ry: Math.PI, h: 0.5 });
    });
    C.HALL_BENCH_X.forEach(function (bx) {
      for (let k = -2; k <= 2; k += 2) S.push({ x: bx + k, z: 28.6, ry: Math.PI, h: 0.5 });
    });
  })();

  /* Builds the whole crowd for a seed. quality 0..1 thins out walkers/sitters for weak devices (cosmetic only). */
  C.generateNPCs = function (seed, quality) {
    quality = quality == null ? 1 : quality;
    const r = C.mulberry32(seed | 0);
    const out = [];
    C.WALK_ZONES.forEach(function (z) {
      const n = Math.max(1, Math.round(z.n * (z.role ? 1 : quality)));
      for (let i = 0; i < n; i++) {
        const K = 5 + ((r() * 3) | 0), pts = [];
        for (let k = 0; k < K; k++) pts.push([z.x1 + 0.5 + r() * (z.x2 - z.x1 - 1), z.z1 + 0.3 + r() * (z.z2 - z.z1 - 0.6)]);
        let L = 0; const lens = [];
        for (let k = 0; k < K; k++) {
          const a = pts[k], b = pts[(k + 1) % K];
          const d = Math.hypot(b[0] - a[0], b[1] - a[1]); lens.push(d); L += d;
        }
        const role = z.role || 'pax';
        out.push({ type: 'walk', role: role, pts: pts, lens: lens, L: Math.max(L, 1),
          speed: role === 'guard' ? 1.0 : 0.9 + r() * 0.7, off: r() * 1000,
          look: role === 'pax' ? paxLook(r) : staffLook(r, role) });
      }
    });
    C.SEATS.forEach(function (s) {
      if (r() < 0.55 * quality + 0.1) { const lk = paxLook(r); lk.acc = lk.acc && lk.acc.kind === 'pack' ? null : lk.acc;
        out.push({ type: 'sit', x: s.x, z: s.z, ry: s.ry, h: s.h, look: lk }); }
    });
    function stand(x, z, ry, role) { out.push({ type: 'stand', x: x, z: z, ry: ry, role: role, look: role === 'pax' ? paxLook(r) : staffLook(r, role) }); }
    C.COUNTER_X.forEach(function (cx) {
      stand(cx, 11.2, Math.PI, 'staff'); stand(cx, 22.3, 0, 'staff');      // staff behind each counter
      if (r() < 0.8) stand(cx + (r() - 0.5) * 3, 14.8, 0, 'pax');           // queueing passengers
      if (r() < 0.8) stand(cx + (r() - 0.5) * 3, 18.2, Math.PI, 'pax');
    });
    C.GATE_X.forEach(function (gx) { stand(gx, -26.5, 0, 'agent'); });
    C.SHOPS.forEach(function (s) { stand(s.side < 0 ? s.x2 + 0.7 : s.x1 - 0.7, (s.z1 + s.z2) / 2, s.side < 0 ? Math.PI / 2 : -Math.PI / 2, 'clerk'); });
    C.LANES.forEach(function (gx) { stand(gx - 3.3, 0.4, Math.PI, 'guard'); stand(gx + 3.3, 0.4, Math.PI, 'guard'); });
    return out;
  };

  /* Writes x,z,ry,moving,s (distance travelled) of a walker at time t (seconds) into out. */
  C.walkerPose = function (n, t, out) {
    const s = ((n.speed * t + n.off) % n.L + n.L) % n.L;
    let acc = 0, i = 0;
    while (i < n.lens.length - 1 && acc + n.lens[i] < s) { acc += n.lens[i]; i++; }
    const a = n.pts[i], b = n.pts[(i + 1) % n.pts.length];
    const f = n.lens[i] > 0 ? (s - acc) / n.lens[i] : 0;
    out.x = a[0] + (b[0] - a[0]) * f; out.z = a[1] + (b[1] - a[1]) * f;
    out.ry = Math.atan2(b[0] - a[0], b[1] - a[1]); out.moving = true; out.s = n.speed * t + n.off;
    return out;
  };

  return C;
});
